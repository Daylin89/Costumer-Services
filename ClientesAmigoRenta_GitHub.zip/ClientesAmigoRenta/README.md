# Clientes Amigo Renta — Android v1.0

Atención al cliente por WhatsApp: captura los mensajes que llegan al WhatsApp Business del teléfono
(acceso a notificaciones), muestra quién espera respuesta, respuestas rápidas con plantillas (envío directo
desde la notificación o abriendo el chat), respuesta automática fuera de horario, casos con categoría,
prioridad, estado, responsable y seguimiento con aviso, reportes en Excel y copia de seguridad.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
