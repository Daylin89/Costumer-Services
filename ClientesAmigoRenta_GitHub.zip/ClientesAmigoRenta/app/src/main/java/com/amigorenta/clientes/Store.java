package com.amigorenta.clientes;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Store {
    static final Locale ES = new Locale("es");
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("clientes", Context.MODE_PRIVATE); }

    static synchronized List<JSONObject> list(Context c, String k) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(k, "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static synchronized void save(Context c, String k, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString(k, a.toString()).commit();
    }

    static synchronized int nextId(Context c) {
        int n = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", n + 1).commit();
        return n;
    }

    static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putS(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static boolean getB(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void putB(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static int getI(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static void putI(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static void put(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception e) { } }

    // ---------- fechas ----------
    static SimpleDateFormat f(String p) { SimpleDateFormat s = new SimpleDateFormat(p, Locale.US); s.setTimeZone(TZ); return s; }
    static SimpleDateFormat fe(String p) { SimpleDateFormat s = new SimpleDateFormat(p, ES); s.setTimeZone(TZ); return s; }
    static Calendar cal() { return Calendar.getInstance(TZ); }
    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }
    static String today() { return f("yyyy-MM-dd").format(new Date()); }
    static String dayOf(long ms) { return f("yyyy-MM-dd").format(new Date(ms)); }
    static String time(long ms) { return f("h:mm a").format(new Date(ms)); }
    static String excelDate(long ms) { return ms <= 0 ? "" : f("yyyy-MM-dd HH:mm").format(new Date(ms)); }

    static String when(long ms) {
        if (ms <= 0) return "";
        String d = dayOf(ms);
        if (d.equals(today())) return time(ms);
        Calendar c = cal();
        c.add(Calendar.DAY_OF_MONTH, -1);
        if (d.equals(f("yyyy-MM-dd").format(c.getTime()))) return "Ayer " + time(ms);
        return cap(fe("EEE d MMM").format(new Date(ms))) + ", " + time(ms);
    }

    static String ago(long ms) {
        long m = Math.max(0, (System.currentTimeMillis() - ms) / 60000);
        if (m < 1) return "ahora";
        if (m < 60) return m + " min";
        long h = m / 60;
        if (h < 24) return h + " h" + (h < 6 && m % 60 > 0 ? " " + (m % 60) + " min" : "");
        return (h / 24) + (h / 24 == 1 ? " día" : " días");
    }

    static long millisAt(String iso, String hm) {
        try { return f("yyyy-MM-dd HH:mm").parse(iso + " " + hm).getTime(); } catch (Exception e) { return 0; }
    }

    // ---------- texto ----------
    static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toUpperCase(Locale.US).replaceAll("[^A-Z0-9+ ]", " ").replaceAll("\\s+", " ").trim();
    }

    static String firstName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.startsWith("+") || n.matches("[0-9 ()+-]+")) return "";
        return n.split("\\s+")[0];
    }

    static String digits(String s) { return s == null ? "" : s.replaceAll("[^0-9]", ""); }

    static boolean looksLikePhone(String s) { return s != null && digits(s).length() >= 10 && s.matches("[0-9 ()+.-]+"); }

    // ---------- horario ----------
    /** días: 7 caracteres L..D con 1/0 */
    static boolean inHours(Context c) {
        Calendar k = cal();
        int dow = k.get(Calendar.DAY_OF_WEEK); // 1 = domingo
        int idx = dow == Calendar.SUNDAY ? 6 : dow - 2;
        String days = get(c, "days", "1111110");
        if (idx < 0 || idx >= days.length() || days.charAt(idx) != '1') return false;
        int now = k.get(Calendar.HOUR_OF_DAY) * 60 + k.get(Calendar.MINUTE);
        return now >= mins(get(c, "open", "09:00")) && now < mins(get(c, "close", "18:00"));
    }

    static int mins(String hm) {
        try { String[] p = hm.split(":"); return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]); } catch (Exception e) { return 0; }
    }

    static String hm12(String hm) {
        try { return f("h:mm a").format(f("HH:mm").parse(hm)); } catch (Exception e) { return hm; }
    }

    static String hoursText(Context c) {
        String days = get(c, "days", "1111110");
        String[] n = {"lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"};
        int first = days.indexOf('1'), last = days.lastIndexOf('1');
        String d;
        if (first < 0) d = "";
        else if (days.substring(first, last + 1).indexOf('0') < 0 && first != last) d = "de " + n[first] + " a " + n[last];
        else {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < 7; i++) if (days.charAt(i) == '1') { if (b.length() > 0) b.append(", "); b.append(n[i]); }
            d = b.toString();
        }
        return d + " de " + hm12(get(c, "open", "09:00")) + " a " + hm12(get(c, "close", "18:00"));
    }

    static String fill(Context c, String tpl, String chatName) {
        String fn = firstName(chatName);
        return tpl.replace("{nombre}", fn).replace("Hola ,", "Hola,").replace("Hola  ", "Hola ")
                .replace("{horario}", hoursText(c))
                .replace("{correo_pagos}", get(c, "payEmail", ""))
                .replace("{telefono}", get(c, "officePhone", "+1 604-767-8650"))
                .replace("{agente}", get(c, "agent", ""));
    }

    static final String DEFAULT_AUTO = "Hola {nombre} 👋 Gracias por escribir a Amigo Renta. En este momento estamos fuera de horario "
            + "(atendemos {horario}, hora de Vancouver). Te responderemos lo antes posible. "
            + "Si es una emergencia en la propiedad (fuga de agua, fuego, gas), llama al 911.";

    static List<JSONObject> templates(Context c) {
        List<JSONObject> l = list(c, "tpls");
        if (!l.isEmpty() || getB(c, "tplInit", false)) return l;
        String[][] d = {
                {"👋 Saludo", "Hola {nombre} 👋 Gracias por comunicarte con Amigo Renta. ¿En qué te podemos ayudar?"},
                {"🕘 Horario", "Nuestro horario de atención es {horario} (hora de Vancouver). 😊"},
                {"🏠 Requisitos para rentar", "Para rentar con nosotros necesitamos: identificación con foto, comprobante de ingresos o estudios, el depósito y el primer mes de renta. ¿Qué zona y presupuesto buscas?"},
                {"💲 Cómo pagar la renta", "Puedes pagar tu renta por e-Transfer a {correo_pagos}. En el mensaje pon tu nombre y número de cuarto. ¡Gracias!"},
                {"🔧 Reparación recibida", "Recibimos tu reporte, {nombre}. Ya lo pasamos al equipo de mantenimiento y te avisamos cuándo van. Si puedes, envíanos una foto del problema."},
                {"📅 Agendar visita", "¡Con gusto te mostramos la habitación! ¿Qué día y hora te queda bien? Las visitas son {horario}."},
                {"✅ Caso resuelto", "Hola {nombre}, te confirmamos que tu solicitud quedó resuelta ✅. Si necesitas algo más, aquí estamos."},
                {"⏳ Seguimos trabajando", "Hola {nombre}, seguimos atendiendo tu caso. Te damos una respuesta a más tardar mañana. Gracias por tu paciencia 🙏"},
                {"🙏 Gracias", "¡Gracias a ti, {nombre}! Que tengas un excelente día. — Amigo Renta"}};
        for (String[] t : d) {
            JSONObject o = new JSONObject();
            put(o, "id", nextId(c));
            put(o, "title", t[0]);
            put(o, "text", t[1]);
            l.add(o);
        }
        save(c, "tpls", l);
        putB(c, "tplInit", true);
        return l;
    }

    // ---------- de qué WhatsApp se leen los mensajes ----------
    /** "business" (por defecto), "personal" o "ambos" */
    static boolean accepts(Context c, String pkg) {
        String src = get(c, "waSource", "business");
        if ("com.whatsapp.w4b".equals(pkg)) return !src.equals("personal");
        if ("com.whatsapp".equals(pkg)) return !src.equals("business");
        return false;
    }

    // ---------- chats y mensajes ----------
    static JSONObject chat(List<JSONObject> chats, String key) {
        for (JSONObject ch : chats) if (ch.optString("key").equals(key)) return ch;
        return null;
    }

    static JSONObject chatById(List<JSONObject> chats, int id) {
        for (JSONObject ch : chats) if (ch.optInt("id") == id) return ch;
        return null;
    }

    /** Guarda mensajes capturados. Devuelve el chat si llegó al menos un mensaje nuevo del cliente. */
    static synchronized JSONObject incoming(Context c, String title, List<String[]> items, boolean group, String pkg) {
        String key = norm(title);
        if (key.isEmpty()) return null;
        List<JSONObject> chats = list(c, "chats");
        List<JSONObject> msgs = list(c, "msgs");
        JSONObject ch = chat(chats, key);
        boolean created = false;
        if (ch == null) {
            ch = new JSONObject();
            put(ch, "id", nextId(c));
            put(ch, "key", key);
            put(ch, "name", title);
            put(ch, "type", "Sin clasificar");
            put(ch, "group", group);
            if (looksLikePhone(title)) put(ch, "phone", title);
            put(ch, "src", "com.whatsapp.w4b".equals(pkg) ? "business" : "personal");
            put(ch, "created", System.currentTimeMillis());
            chats.add(ch);
            created = true;
        }
        int cid = ch.optInt("id");
        boolean newIn = false;
        for (String[] it : items) {
            String text = it[0], dir = it[2];
            long at;
            try { at = Long.parseLong(it[1]); } catch (Exception e) { at = System.currentTimeMillis(); }
            if (text == null || text.trim().isEmpty()) continue;
            String mk = cid + "|" + at + "|" + text.hashCode();
            boolean dup = false;
            for (int i = msgs.size() - 1; i >= 0 && i >= msgs.size() - 400; i--)
                if (msgs.get(i).optString("k").equals(mk)) { dup = true; break; }
            if (dup) continue;
            JSONObject m = new JSONObject();
            put(m, "cid", cid);
            put(m, "at", at);
            put(m, "text", text);
            put(m, "dir", dir);
            put(m, "k", mk);
            msgs.add(m);
            if ("in".equals(dir)) {
                newIn = true;
                if (at > ch.optLong("lastIn")) { put(ch, "lastIn", at); put(ch, "lastText", text); }
                put(ch, "unread", ch.optInt("unread") + 1);
            } else if (at > ch.optLong("lastOut")) { put(ch, "lastOut", at); put(ch, "lastText", "Tú: " + text); }
        }
        if (!newIn && !created) { save(c, "msgs", trim(msgs)); save(c, "chats", chats); return null; }
        save(c, "msgs", trim(msgs));
        save(c, "chats", chats);
        return newIn ? ch : null;
    }

    static List<JSONObject> trim(List<JSONObject> msgs) {
        while (msgs.size() > 6000) msgs.remove(0);
        return msgs;
    }

    static synchronized void logOut(Context c, int cid, String text, String dir) {
        List<JSONObject> chats = list(c, "chats");
        List<JSONObject> msgs = list(c, "msgs");
        long now = System.currentTimeMillis();
        JSONObject m = new JSONObject();
        put(m, "cid", cid);
        put(m, "at", now);
        put(m, "text", text);
        put(m, "dir", dir);
        put(m, "k", cid + "|" + now + "|" + text.hashCode());
        msgs.add(m);
        JSONObject ch = chatById(chats, cid);
        if (ch != null) {
            put(ch, "lastOut", now);
            put(ch, "lastText", ("auto".equals(dir) ? "🤖 " : "Tú: ") + text);
            if (!"auto".equals(dir)) { put(ch, "attended", now); put(ch, "unread", 0); put(ch, "lastRead", now); }
            else put(ch, "lastAuto", now);
        }
        save(c, "msgs", trim(msgs));
        save(c, "chats", chats);
    }

    static synchronized void markRead(Context c, String title) {
        List<JSONObject> chats = list(c, "chats");
        JSONObject ch = chat(chats, norm(title));
        if (ch == null) return;
        put(ch, "lastRead", System.currentTimeMillis());
        put(ch, "unread", 0);
        save(c, "chats", chats);
    }

    /** 0 sin leer, 1 leído sin atender, 2 atendido */
    static int state(JSONObject ch) {
        long in = ch.optLong("lastIn");
        if (in <= 0) return 2;
        if (in > ch.optLong("lastRead") && ch.optInt("unread") > 0) return 0;
        if (in > Math.max(ch.optLong("attended"), ch.optLong("lastOut"))) return 1;
        return 2;
    }

    static boolean shouldAutoReply(Context c, JSONObject ch) {
        if (!getB(c, "autoReply", true) || ch.optBoolean("group") || ch.optBoolean("noAuto")) return false;
        if (inHours(c)) return false;
        long gap = getI(c, "autoGap", 12) * 3600000L;
        return System.currentTimeMillis() - ch.optLong("lastAuto") > gap;
    }

    // ---------- WhatsApp ----------
    static boolean installed(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
    }

    static String waPkg(Context c) {
        String pref = get(c, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        if (installed(c, pref)) return pref;
        if (installed(c, "com.whatsapp.w4b")) return "com.whatsapp.w4b";
        if (installed(c, "com.whatsapp")) return "com.whatsapp";
        return null;
    }

    static Intent waIntent(Context c, String phone, String text) {
        String d = digits(phone);
        if (d.length() == 10) d = "1" + d;
        String url = "https://wa.me/" + d + (text == null || text.isEmpty() ? "" : "?text=" + Uri.encode(text));
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        String pkg = waPkg(c);
        if (pkg != null) i.setPackage(pkg);
        return i;
    }

    // ---------- avisos ----------
    static void notifyNow(Context c, int code, String title, String text, int cid) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("clientes", "Clientes Amigo Renta", NotificationManager.IMPORTANCE_DEFAULT));
            Intent oi = new Intent(c, MainActivity.class);
            if (cid > 0) oi.putExtra("chat", cid);
            oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent open = PendingIntent.getActivity(c, code, oi, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            nm.notify(code, new Notification.Builder(c, "clientes")
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setContentTitle(title).setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(open).setAutoCancel(true).build());
        } catch (Exception e) { }
    }

    static void scheduleFollow(Context c, JSONObject cs, JSONObject ch) {
        cancelFollow(c, cs.optInt("id"));
        long when = cs.optLong("follow");
        if (when <= System.currentTimeMillis() || "Resuelto".equals(cs.optString("status"))) return;
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("title", "📌 Seguimiento: " + cs.optString("title"));
        i.putExtra("text", (ch != null ? ch.optString("name") + " · " : "") + cs.optString("category") + " · " + cs.optString("status")
                + (cs.optString("assigned").isEmpty() ? "" : " · " + cs.optString("assigned")));
        i.putExtra("code", 20000 + cs.optInt("id"));
        if (ch != null && !ch.optString("phone").isEmpty()) {
            i.putExtra("action", "Escribirle por WhatsApp");
            i.putExtra("waPhone", ch.optString("phone"));
            i.putExtra("waText", fill(c, "Hola {nombre}, te escribimos de Amigo Renta para darte seguimiento a tu caso: " + cs.optString("title") + ".", ch.optString("name")));
        }
        PendingIntent pi = PendingIntent.getBroadcast(c, 20000 + cs.optInt("id"), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    static void cancelFollow(Context c, int id) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 20000 + id, new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel(); }
    }

    static void scheduleAllFollowups(Context c) {
        List<JSONObject> chats = list(c, "chats");
        for (JSONObject cs : list(c, "cases")) scheduleFollow(c, cs, chatById(chats, cs.optInt("cid")));
    }
}
