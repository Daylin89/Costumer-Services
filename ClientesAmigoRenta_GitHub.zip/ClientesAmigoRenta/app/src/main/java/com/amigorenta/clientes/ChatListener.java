package com.amigorenta.clientes;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatListener extends NotificationListenerService {
    /** Acción "Responder" de la última notificación de cada chat (para responder sin abrir WhatsApp). */
    static final Map<String, Notification.Action> REPLIES = new HashMap<>();

    static boolean isWa(String pkg) { return "com.whatsapp".equals(pkg) || "com.whatsapp.w4b".equals(pkg); }

    static String cs(CharSequence s) { return s == null ? "" : s.toString(); }

    static String cleanTitle(String t) {
        return t.replaceAll("\\s*\\(\\d+\\s+[^)]*\\)\\s*$", "").replaceAll("^\\s*\\u200e?", "").trim();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || !isWa(sbn.getPackageName())) return;
            if (!Store.accepts(getApplicationContext(), sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            if (Notification.CATEGORY_CALL.equals(n.category) || Notification.CATEGORY_MISSED_CALL.equals(n.category)) return;
            Bundle e = n.extras;
            boolean group = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false);
            String title = cs(e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
            if (title.isEmpty()) title = cs(e.getCharSequence(Notification.EXTRA_TITLE));
            title = cleanTitle(title);
            if (title.isEmpty()) return;
            String low = title.toLowerCase();
            if (low.equals("whatsapp") || low.equals("whatsapp business") || low.contains("whatsapp web")) return;
            Context c = getApplicationContext();
            if (group && !Store.getB(c, "groups", false)) return;

            List<String[]> items = new ArrayList<>();
            Parcelable[] arr = e.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (arr != null && arr.length > 0) {
                List<Notification.MessagingStyle.Message> ms = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr);
                for (Notification.MessagingStyle.Message m : ms) {
                    boolean me;
                    if (android.os.Build.VERSION.SDK_INT >= 28) me = m.getSenderPerson() == null;
                    else me = m.getSender() == null;
                    String txt = cs(m.getText());
                    if (group && !me) {
                        String who = android.os.Build.VERSION.SDK_INT >= 28 && m.getSenderPerson() != null ? cs(m.getSenderPerson().getName()) : cs(m.getSender());
                        if (!who.isEmpty()) txt = who + ": " + txt;
                    }
                    items.add(new String[]{txt, String.valueOf(m.getTimestamp()), me ? "out" : "in"});
                }
            } else {
                String txt = cs(e.getCharSequence(Notification.EXTRA_TEXT));
                String tl = txt.toLowerCase();
                if (tl.matches("^\\d+ (mensajes|new messages|messages|nuevos mensajes).*") || tl.contains("comprobando si hay mensajes") || tl.contains("checking for new messages")) return;
                items.add(new String[]{txt, String.valueOf(sbn.getPostTime()), "in"});
            }

            String key = Store.norm(title);
            if (n.actions != null) for (Notification.Action a : n.actions) {
                RemoteInput[] ri = a.getRemoteInputs();
                if (ri != null && ri.length > 0) { REPLIES.put(key, a); break; }
            }

            JSONObject ch = Store.incoming(c, title, items, group, sbn.getPackageName());
            if (ch != null) {
                if (Store.shouldAutoReply(c, ch)) {
                    String text = Store.fill(c, Store.get(c, "autoText", Store.DEFAULT_AUTO), ch.optString("name"));
                    if (reply(c, key, text)) Store.logOut(c, ch.optInt("id"), text, "auto");
                }
            }
        } catch (Exception ignored) { }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rankingMap, int reason) {
        try {
            if (sbn == null || !isWa(sbn.getPackageName())) return;
            if (!Store.accepts(getApplicationContext(), sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            String title = cs(n.extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
            if (title.isEmpty()) title = cs(n.extras.getCharSequence(Notification.EXTRA_TITLE));
            title = cleanTitle(title);
            if (title.isEmpty()) return;
            REPLIES.remove(Store.norm(title));
            if (reason == REASON_CLICK || reason == REASON_APP_CANCEL || reason == REASON_APP_CANCEL_ALL)
                Store.markRead(getApplicationContext(), title);
        } catch (Exception ignored) { }
    }

    /** Responde usando la notificación de WhatsApp (sin abrir el chat). */
    static boolean reply(Context c, String key, String text) {
        Notification.Action a = REPLIES.get(key);
        if (a == null) return false;
        try {
            RemoteInput[] ri = a.getRemoteInputs();
            Intent i = new Intent();
            Bundle b = new Bundle();
            for (RemoteInput r : ri) b.putCharSequence(r.getResultKey(), text);
            RemoteInput.addResultsToIntent(ri, i, b);
            a.actionIntent.send(c, 0, i);
            return true;
        } catch (Exception e) {
            REPLIES.remove(key);
            return false;
        }
    }
}
