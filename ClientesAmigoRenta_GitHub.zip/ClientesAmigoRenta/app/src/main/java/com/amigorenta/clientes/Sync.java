package com.amigorenta.clientes;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Sincroniza chats, casos y mensajes con el servidor (panel web).
 * Se envían solo los campos que cambiaron desde la última sincronización; el servidor guarda el último valor de cada campo.
 */
public class Sync {
    static final String[] CHAT_F = {"name", "phone", "type", "property", "room", "notes", "lastIn", "lastOut", "lastText", "attended", "attendedBy",
            "lastRead", "unread", "assigned", "group", "src", "created", "noAuto"};
    static final String[] CASE_F = {"title", "desc", "category", "priority", "status", "assigned", "follow", "created", "resolved", "by", "log", "trello", "chat", "operator", "costs", "trelloTo"};
    static volatile long lastRun = 0;
    static volatile boolean running = false;
    /** true mientras la pantalla muestra un formulario: la sincronización automática espera. */
    static volatile boolean hold = false, deferred = false;
    /** La pantalla principal se entera de que llegaron cambios. */
    static volatile Runnable onChange = null;

    static boolean on(Context c) { return Net.ready(c); }

    /** Valor normalizado para comparar (números sin decimales sobrantes, vacío = ""). */
    static String norm(Object v) {
        if (v == null || v == JSONObject.NULL) return "";
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == 0) return "";
            return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d);
        }
        if (v instanceof Boolean) return ((Boolean) v) ? "true" : "";
        return v.toString();
    }

    static String devTag(Context c) {
        String t = Store.get(c, "devTag", "");
        if (t.isEmpty()) { t = Long.toString(System.nanoTime() % 2176782336L, 36); Store.putS(c, "devTag", t); }
        return t;
    }

    static JSONObject snap(Context c) {
        try { return new JSONObject(Store.get(c, "syncSnap", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static Object caseVal(JSONObject cs, String k, Map<Integer, String> keyOf) {
        if (k.equals("chat")) { String s = keyOf.get(cs.optInt("cid")); return s == null ? "" : s; }
        return cs.opt(k);
    }

    /** Ejecuta en segundo plano (no en la pantalla). Devuelve null si salió bien o el mensaje de error. */
    static String run(Context c) {
        if (!on(c)) return "Falta configurar el servidor";
        if (running) return null;
        running = true;
        try { return doRun(c); } finally { running = false; lastRun = System.currentTimeMillis(); }
    }

    /** Sincronización automática: espera si hay un formulario abierto. */
    static void auto(Context c) {
        if (hold) { deferred = true; return; }
        deferred = false;
        run(c);
    }

    static String doRun(Context c) {
        // ---------- 1. armar lo que cambió ----------
        JSONObject snap = snap(c);
        Map<String, Map<String, String>> base = new HashMap<>(); // valores con los que se comparará al aplicar
        JSONArray pc = new JSONArray(), pk = new JSONArray(), pm = new JSONArray();
        long maxMsg;
        boolean chg;
        List<JSONObject> chats, cases, msgs;
        synchronized (Store.class) {
            chats = Store.list(c, "chats");
            cases = Store.list(c, "cases");
            msgs = Store.list(c, "msgs");
            boolean uidAdded = false;
            for (JSONObject cs : cases) if (cs.optString("uid").isEmpty()) { Store.put(cs, "uid", "d-" + devTag(c) + "-" + cs.optInt("id")); uidAdded = true; }
            if (uidAdded) Store.save(c, "cases", cases);
        }
        Map<Integer, String> keyOf = new HashMap<>();
        for (JSONObject ch : chats) keyOf.put(ch.optInt("id"), ch.optString("key"));
        try {
            for (JSONObject ch : chats) {
                String id = "chat:" + ch.optString("key");
                JSONObject s = snap.optJSONObject(id);
                JSONObject set = new JSONObject();
                Map<String, String> b = new HashMap<>();
                for (String k : CHAT_F) {
                    String now = norm(ch.opt(k)), old = s == null ? null : s.optString(k, "");
                    b.put(k, now);
                    if (old == null || !now.equals(old)) if (!(old == null && now.isEmpty())) set.put(k, ch.opt(k) == null ? "" : ch.opt(k));
                }
                base.put(id, b);
                if (set.length() > 0) pc.put(new JSONObject().put("id", ch.optString("key")).put("set", set));
            }
            java.util.Set<String> live = new java.util.HashSet<>();
            for (JSONObject cs : cases) {
                String id = "case:" + cs.optString("uid");
                live.add(id);
                JSONObject s = snap.optJSONObject(id);
                JSONObject set = new JSONObject();
                Map<String, String> b = new HashMap<>();
                for (String k : CASE_F) {
                    Object v = caseVal(cs, k, keyOf);
                    String now = norm(v), old = s == null ? null : s.optString(k, "");
                    b.put(k, now);
                    if (old == null || !now.equals(old)) if (!(old == null && now.isEmpty())) set.put(k, v == null ? "" : v);
                }
                base.put(id, b);
                if (set.length() > 0) pk.put(new JSONObject().put("id", cs.optString("uid")).put("set", set));
            }
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { // casos borrados en el teléfono
                String id = it.next();
                if (id.startsWith("case:") && !live.contains(id)) pk.put(new JSONObject().put("id", id.substring(5)).put("set", new JSONObject().put("deleted", true)));
            }
            long since = Store.sp(c).getLong("lastMsgSync", 0);
            maxMsg = since;
            int n = 0;
            for (JSONObject m : msgs) {
                long at = m.optLong("at");
                if (at <= since || n >= 800) continue;
                String key = keyOf.get(m.optInt("cid"));
                if (key == null) continue;
                pm.put(new JSONObject().put("chat", key).put("at", at).put("dir", m.optString("dir")).put("text", m.optString("text")));
                maxMsg = Math.max(maxMsg, at);
                n++;
            }
            JSONObject body = new JSONObject().put("chats", pc).put("cases", pk).put("msgs", pm);
            JSONObject cfg = cfg(c);
            if (!norm(cfg.toString()).equals(Store.get(c, "syncCfg", ""))) body.put("cfg", new JSONObject().put("set", cfg));
            // ---------- 2. enviar ----------
            if (pc.length() + pk.length() + pm.length() > 0 || body.has("cfg")) {
                Net.Res r = Net.request(c, "POST", "/api/push", body.toString().getBytes(StandardCharsets.UTF_8), "application/json", null);
                if (r.error != null || r.code != 200) return Net.errorOf(r.code, r.body, r.error);
                if (body.has("cfg")) Store.putS(c, "syncCfg", norm(cfg.toString()));
                Store.sp(c).edit().putLong("lastMsgSync", maxMsg).apply();
            }
            // lo enviado ya es la base conocida
            for (Map.Entry<String, Map<String, String>> e : base.entrySet()) snap.put(e.getKey(), new JSONObject(e.getValue()));
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { String id = it.next(); if (id.startsWith("case:") && !live.contains(id)) it.remove(); }
            // ---------- 3. traer cambios ----------
            long lastPull = Store.sp(c).getLong("lastPull", 0);
            Net.Res r = Net.request(c, "GET", "/api/changes?since=" + Math.max(0, lastPull - 120000), null, null, null);
            if (r.error != null || r.code != 200) { Store.putS(c, "syncSnap", snap.toString()); return Net.errorOf(r.code, r.body, r.error); }
            JSONObject res = new JSONObject(Net.text(r.body));
            JSONArray recs = res.getJSONArray("records");
            // ---------- 4. aplicar ----------
            synchronized (Store.class) {
                List<JSONObject> lc = Store.list(c, "chats"), lk = Store.list(c, "cases");
                chg = false;
                List<JSONObject> followUps = new ArrayList<>();
                for (int i = 0; i < recs.length(); i++) {
                    JSONObject rec = recs.getJSONObject(i);
                    String kind = rec.optString("kind"), rid = rec.optString("id");
                    JSONObject data = rec.optJSONObject("data");
                    if (data == null) continue;
                    if (kind.equals("chat")) {
                        String sid = "chat:" + rid;
                        JSONObject ch = Store.chat(lc, rid);
                        JSONObject s = snap.optJSONObject(sid);
                        if (ch == null) {
                            ch = new JSONObject();
                            Store.put(ch, "id", Store.nextId(c));
                            Store.put(ch, "key", rid);
                            lc.add(ch);
                            s = null;
                        }
                        JSONObject ns = new JSONObject();
                        for (String k : CHAT_F) {
                            Object sv = data.opt(k);
                            String cur = norm(ch.opt(k)), was = s == null ? cur : s.optString(k, "");
                            if (cur.equals(was)) { if (sv != null) { if (!norm(sv).equals(cur)) chg = true; ch.put(k, sv); } ns.put(k, norm(sv)); }
                            else ns.put(k, was); // cambió aquí mientras sincronizaba: se manda la próxima vez
                        }
                        snap.put(sid, ns);
                    } else if (kind.equals("case")) {
                        String sid = "case:" + rid;
                        JSONObject cs = null;
                        for (JSONObject x : lk) if (x.optString("uid").equals(rid)) cs = x;
                        if (data.optBoolean("deleted")) {
                            if (cs != null) { lk.remove(cs); Store.cancelFollow(c, cs.optInt("id")); chg = true; }
                            snap.remove(sid);
                            continue;
                        }
                        JSONObject s = snap.optJSONObject(sid);
                        if (cs == null) {
                            cs = new JSONObject();
                            Store.put(cs, "id", Store.nextId(c));
                            Store.put(cs, "uid", rid);
                            lk.add(cs);
                            s = null;
                        }
                        Map<Integer, String> ko = new HashMap<>();
                        for (JSONObject ch : lc) ko.put(ch.optInt("id"), ch.optString("key"));
                        JSONObject ns = new JSONObject();
                        for (String k : CASE_F) {
                            Object sv = data.opt(k);
                            String cur = norm(caseVal(cs, k, ko)), was = s == null ? cur : s.optString(k, "");
                            if (cur.equals(was)) {
                                if (sv != null) {
                                    if (!norm(sv).equals(cur)) chg = true;
                                    if (k.equals("chat")) { JSONObject ch = Store.chat(lc, String.valueOf(sv)); Store.put(cs, "cid", ch == null ? 0 : ch.optInt("id")); }
                                    else cs.put(k, sv);
                                }
                                ns.put(k, norm(sv));
                            } else ns.put(k, was);
                        }
                        snap.put(sid, ns);
                        followUps.add(cs);
                    }
                }
                if (chg) { Store.save(c, "chats", lc); Store.save(c, "cases", lk); }
                for (JSONObject cs : followUps) Store.scheduleFollow(c, cs, Store.chatById(lc, cs.optInt("cid")));
                Store.putS(c, "syncSnap", snap.toString());
                Store.sp(c).edit().putLong("lastPull", res.optLong("now")).putLong("lastSyncOk", System.currentTimeMillis()).apply();
            }
            if (chg) { Runnable r2 = onChange; if (r2 != null) H.post(() -> { Runnable r3 = onChange; if (r3 != null) r3.run(); }); }
            return null;
        } catch (Exception e) {
            return "Error al sincronizar: " + e.getMessage();
        }
    }

    /** Ajustes del teléfono que también usa el panel web. */
    static JSONObject cfg(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("trelloEmail", Store.get(c, "trelloEmail", ""));
            o.put("opsName", Store.get(c, "opsName", ""));
            o.put("trelloUser", Store.get(c, "trelloUser", ""));
            o.put("payEmail", Store.get(c, "payEmail", ""));
            o.put("officePhone", Store.get(c, "officePhone", "+1 604-767-8650"));
            o.put("hours", Store.hoursText(c));
            JSONArray ag = new JSONArray();
            List<String> l = new ArrayList<>();
            for (String x : (Store.get(c, "agent", "") + "," + Store.get(c, "opsName", "") + "," + Store.get(c, "others", "")).split(","))
                if (!x.trim().isEmpty() && !l.contains(x.trim())) { l.add(x.trim()); ag.put(x.trim()); }
            o.put("agents", ag);
            o.put("operators", new JSONArray(Store.get(c, "operators", "[]")));
            JSONArray tp = new JSONArray();
            for (JSONObject t : Store.templates(c)) tp.put(new JSONObject().put("title", t.optString("title")).put("text", t.optString("text")));
            o.put("tpls", tp);
        } catch (Exception ignored) { }
        return o;
    }

    // ---------- cuándo sincronizar ----------
    static final Handler H = new Handler(Looper.getMainLooper());
    static final Runnable[] PENDING = {null};

    /** Pide sincronizar pronto (agrupa varios cambios seguidos). */
    static void soon(Context c, long delayMs) {
        if (!on(c)) return;
        final Context app = c.getApplicationContext();
        if (PENDING[0] != null) H.removeCallbacks(PENDING[0]);
        PENDING[0] = () -> new Thread(() -> auto(app)).start();
        H.postDelayed(PENDING[0], delayMs);
    }

    static void schedule(Context c) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 31, new Intent(c, Rx.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE))
                .setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_FIFTEEN_MINUTES, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi);
    }

    /** Sincroniza cada ~15 minutos aunque la app esté cerrada. */
    public static class Rx extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            if (!on(c)) return;
            final PendingResult pr = goAsync();
            new Thread(() -> { try { auto(c); } finally { pr.finish(); } }).start();
        }
    }
}
