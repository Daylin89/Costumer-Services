package com.amigorenta.clientes;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, WA = 0xFF128C7E, YEL = 0xFFB45309;
    static final String[] TYPES = {"Sin clasificar", "Inquilino", "Interesado en rentar", "Agencia / escuela", "Proveedor", "Otro"};
    static final String[] CATS = {"🔧 Reparación / mantenimiento", "💲 Pago / renta", "😟 Queja", "❓ Consulta", "🏠 Interesado en rentar",
            "📦 Mudanza (entrada / salida)", "🧹 Limpieza", "📄 Contrato / documentos", "📌 Otro"};
    static final String[] PRIOS = {"🔴 Urgente", "🟠 Alta", "🔵 Normal", "⚪ Baja"};
    static final String[] STATUS = {"Nuevo", "En proceso", "Esperando al cliente", "Resuelto"};
    static final int[][] ST_COL = {{0xFF1D4ED8, 0xFFE4ECFF}, {0xFFB45309, 0xFFFFF1DB}, {0xFF7C3AED, 0xFFF0E9FF}, {0xFF15803D, 0xFFE3F6E8}};
    static final int REQ_EXPORT = 61;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;

    interface Cb { void on(String s); }

    List<JSONObject> chats, msgs, cases, tpls;
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String chatFilter = "Todos", caseFilter = "Abiertos", search = "";

    // ============================ ciclo de vida ============================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        reload();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        fab = tv("", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);
        setContentView(root);
        Backup.autoBackup(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        if (Store.get(this, "agent", "").isEmpty()) { tabSel = 3; open(() -> settings(true)); }
        else {
            openTab(0);
            handleIntent(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        reload();
        handleIntent(i);
    }

    void handleIntent(Intent i) {
        if (i != null && i.getIntExtra("chat", 0) > 0) {
            final int cid = i.getIntExtra("chat", 0);
            open(() -> chatScreen(cid));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
        if (!stack.isEmpty()) stack.get(stack.size() - 1).run();
    }

    void reload() {
        chats = Store.list(this, "chats");
        msgs = Store.list(this, "msgs");
        cases = Store.list(this, "cases");
        tpls = Store.templates(this);
    }

    void saveChats() { Store.save(this, "chats", chats); }
    void saveCases() { Store.save(this, "cases", cases); }

    // ============================ navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::chatsScreen);
        else if (k == 1) open(this::casesScreen);
        else if (k == 2) open(this::tplScreen);
        else open(this::more);
    }

    void goBack() {
        if (stack.size() > 1) { stack.remove(stack.size() - 1); stack.get(stack.size() - 1).run(); }
        else if (tabSel != 0) openTab(0);
        else finish();
    }

    void refresh() { if (!stack.isEmpty()) stack.get(stack.size() - 1).run(); }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        TextView tt = tv(title, 20, Color.WHITE, true);
        tt.setMaxLines(1);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(tt);
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, String fabText, Runnable fabAction) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        if (fabText != null) {
            fab.setText(fabText);
            fab.setOnClickListener(v -> fabAction.run());
            fab.setVisibility(View.VISIBLE);
        } else fab.setVisibility(View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"💬", "Chats"}, {"📋", "Casos"}, {"⚡", "Respuestas"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFEAF1FF, 12) : null);
        }
    }

    boolean listenerOn() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(new ComponentName(this, ChatListener.class).flattenToString());
    }

    // ============================ chats ============================
    static final String[] CH_ICON = {"🔴", "🟡", "✅"};
    static final String[] CH_NAME = {"Sin leer", "Leído, sin atender", "Atendido"};
    static final int[] CH_COL = {0xFFB91C1C, 0xFFB45309, 0xFF15803D};

    int openCases(int cid) {
        int n = 0;
        for (JSONObject cs : cases) if (cs.optInt("cid") == cid && !"Resuelto".equals(cs.optString("status"))) n++;
        return n;
    }

    void chatsScreen() {
        int[] cnt = new int[3];
        for (JSONObject ch : chats) cnt[Store.state(ch)]++;
        boolean on = listenerOn();
        setHeader("Atención al cliente", (Store.inHours(this) ? "🟢 En horario" : "🌙 Fuera de horario")
                + (Store.getB(this, "autoReply", true) ? " · respuesta automática activa" : ""), "💬", false);
        LinearLayout p = vbox();
        if (!on) {
            LinearLayout w = card();
            w.setBackground(round(0xFFFDE6E6, 16));
            w.addView(tv("🔴  Conexión con WhatsApp desactivada", 16, 0xFFB91C1C, true));
            w.addView(tv("Actívala para que los mensajes lleguen solos a la app.", 14, TXT, false));
            TextView go = tv("Activar ›", 15, 0xFFB91C1C, true);
            go.setPadding(0, dp(8), 0, 0);
            go.setOnClickListener(v -> open(this::connectScreen));
            w.addView(go);
            p.addView(w);
        }
        LinearLayout row = hbox();
        row.setPadding(dp(10), dp(6), dp(10), 0);
        for (int i = 0; i < 3; i++) row.addView(stat(CH_ICON[i], cnt[i], i == 0 ? "Sin leer" : i == 1 ? "Sin atender" : "Atendidos", CH_COL[i]));
        p.addView(row);
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(4), dp(10), 0);
        for (String o : new String[]{"Todos", "Esperando respuesta", "Inquilinos", "Interesados", "Con casos abiertos"})
            chips.addView(chip(o, o.equals(chatFilter), v -> { chatFilter = o; chatsScreen(); }));
        p.addView(hscroll(chips));
        EditText s = input("🔍  Buscar nombre, número o texto", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(6), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            list.removeAllViews();
            String q = Store.norm(search);
            List<JSONObject> l = new ArrayList<>();
            for (JSONObject ch : chats) {
                int st = Store.state(ch);
                if (chatFilter.equals("Esperando respuesta") && st == 2) continue;
                if (chatFilter.equals("Inquilinos") && !ch.optString("type").equals("Inquilino")) continue;
                if (chatFilter.equals("Interesados") && !ch.optString("type").equals("Interesado en rentar")) continue;
                if (chatFilter.equals("Con casos abiertos") && openCases(ch.optInt("id")) == 0) continue;
                if (!q.isEmpty() && !Store.norm(ch.optString("name") + " " + ch.optString("phone") + " " + ch.optString("lastText") + " " + ch.optString("property")).contains(q)) continue;
                l.add(ch);
            }
            Collections.sort(l, (x, y) -> {
                int a = Store.state(x), c = Store.state(y);
                if (a != c) return Integer.compare(a, c);
                long lx = Math.max(x.optLong("lastIn"), x.optLong("lastOut")), ly = Math.max(y.optLong("lastIn"), y.optLong("lastOut"));
                return a == 2 ? Long.compare(ly, lx) : Long.compare(x.optLong("lastIn"), y.optLong("lastIn"));
            });
            if (chats.isEmpty()) list.addView(empty(on ? "Todavía no han llegado mensajes.\nCuando un cliente escriba al WhatsApp de este teléfono, aparecerá aquí."
                    : "Activa la conexión con WhatsApp para empezar."));
            else if (l.isEmpty()) list.addView(empty("No hay chats con este filtro"));
            for (int i = 0; i < l.size() && i < 300; i++) list.addView(chatRow(l.get(i)));
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fill.run(); }
        });
        fill.run();
        show(scroll(p), true, "＋  Cliente", this::newChatDialog);
    }

    View stat(String ic, int n, String label, int fg) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(Color.WHITE, 14));
        b.setElevation(dp(1));
        b.setPadding(0, dp(10), 0, dp(10));
        TextView num = tv(ic + " " + n, 20, fg, true);
        num.setGravity(Gravity.CENTER);
        TextView l = tv(label, 11, MUT, false);
        l.setGravity(Gravity.CENTER);
        b.addView(num);
        b.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    View chatRow(JSONObject ch) {
        int st = Store.state(ch);
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(avatar(ch.optString("name").replaceAll("^[^A-Za-zÀ-ÿ0-9]+", ""), st == 0 ? 0xFFDC2626 : WA, 46));
        LinearLayout v = vbox();
        v.setPadding(dp(12), 0, dp(6), 0);
        LinearLayout top = hbox();
        TextView nm = tv(ch.optString("name"), 16, TXT, true);
        nm.setMaxLines(1);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
        long last = Math.max(ch.optLong("lastIn"), ch.optLong("lastOut"));
        top.addView(tv(Store.when(last), 12, MUT, false));
        v.addView(top);
        String sub = join(" · ", ch.optString("type").equals("Sin clasificar") ? "" : ch.optString("type"), ch.optString("property"),
                ch.optString("room").isEmpty() ? "" : "Cuarto " + ch.optString("room"));
        if (!sub.isEmpty()) v.addView(tv(sub, 12, PRI2, true));
        TextView lt = tv(ch.optString("lastText"), 14, MUT, false);
        lt.setMaxLines(2);
        lt.setEllipsize(TextUtils.TruncateAt.END);
        v.addView(lt);
        String state = CH_ICON[st] + " " + CH_NAME[st] + (st < 2 ? " · espera " + Store.ago(ch.optLong("lastIn")) : "");
        int oc = openCases(ch.optInt("id"));
        v.addView(tv(state + (oc > 0 ? "  ·  📋 " + oc + (oc == 1 ? " caso" : " casos") : ""), 12, CH_COL[st], true));
        c.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        final int id = ch.optInt("id");
        c.setOnClickListener(x -> open(() -> chatScreen(id)));
        return c;
    }

    void newChatDialog() {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText n = input("Nombre", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText ph = input("WhatsApp (ej. +1 604 555 1111)", InputType.TYPE_CLASS_PHONE);
        box.addView(n);
        box.addView(ph);
        new AlertDialog.Builder(this).setTitle("Nuevo cliente").setView(box)
                .setPositiveButton("Guardar", (dlg, w) -> {
                    String nm = n.getText().toString().trim();
                    if (nm.isEmpty()) nm = ph.getText().toString().trim();
                    if (nm.isEmpty()) return;
                    JSONObject ch = Store.chat(chats, Store.norm(nm));
                    if (ch == null) {
                        ch = new JSONObject();
                        Store.put(ch, "id", Store.nextId(this));
                        Store.put(ch, "key", Store.norm(nm));
                        Store.put(ch, "name", nm);
                        Store.put(ch, "type", "Sin clasificar");
                        Store.put(ch, "created", System.currentTimeMillis());
                        chats.add(ch);
                    }
                    Store.put(ch, "phone", ph.getText().toString().trim());
                    saveChats();
                    final int id = ch.optInt("id");
                    open(() -> chatScreen(id));
                }).setNegativeButton("Cancelar", null).show();
    }

    // ============================ conversación ============================
    void chatScreen(int cid) {
        final JSONObject ch = Store.chatById(chats, cid);
        if (ch == null) { goBack(); return; }
        setHeader(ch.optString("name"), ch.optString("phone").isEmpty() ? ch.optString("type") : ch.optString("phone"), null, true);
        final ScrollView sv = new ScrollView(this);
        LinearLayout p = vbox();
        p.setPadding(0, dp(6), 0, dp(12));
        sv.addView(p);

        LinearLayout info = card();
        LinearLayout ir = hbox();
        LinearLayout iv = vbox();
        String sub = join(" · ", ch.optString("type"), ch.optString("property"), ch.optString("room").isEmpty() ? "" : "Cuarto " + ch.optString("room"));
        iv.addView(tv(sub, 14, PRI2, true));
        if (!ch.optString("notes").isEmpty()) iv.addView(tv("📝 " + ch.optString("notes"), 13, MUT, false));
        ir.addView(iv, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView ed = tv("✏️", 20, PRI2, false);
        ed.setPadding(dp(10), 0, 0, 0);
        ed.setOnClickListener(v -> open(() -> contactForm(cid)));
        ir.addView(ed);
        info.addView(ir);
        int st = Store.state(ch);
        LinearLayout sr = hbox();
        sr.setPadding(0, dp(8), 0, 0);
        sr.addView(tv(CH_ICON[st] + " " + CH_NAME[st], 13, CH_COL[st], true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (st != 2) {
            TextView att = tv("✅ Marcar atendido", 13, GRN, true);
            att.setOnClickListener(v -> {
                Store.put(ch, "attended", System.currentTimeMillis());
                Store.put(ch, "unread", 0);
                Store.put(ch, "lastRead", System.currentTimeMillis());
                saveChats();
                refresh();
            });
            sr.addView(att);
        }
        info.addView(sr);
        p.addView(info);

        List<JSONObject> cc = new ArrayList<>();
        for (JSONObject cs : cases) if (cs.optInt("cid") == cid) cc.add(cs);
        Collections.sort(cc, (x, y) -> Long.compare(y.optLong("created"), x.optLong("created")));
        LinearLayout cr = hbox();
        cr.setPadding(dp(10), 0, dp(10), 0);
        cr.addView(smallBtn("📋 Abrir caso", PRI2, v -> open(() -> caseForm(-1, cid))), weightLp(1f));
        cr.addView(smallBtn("💬 Abrir WhatsApp", WA, v -> openWa(ch, "")), weightLp(1f));
        p.addView(cr);
        for (JSONObject cs : cc) if (!"Resuelto".equals(cs.optString("status"))) p.addView(caseRow(cs, false));

        List<JSONObject> mm = new ArrayList<>();
        for (JSONObject m : msgs) if (m.optInt("cid") == cid) mm.add(m);
        Collections.sort(mm, (x, y) -> Long.compare(x.optLong("at"), y.optLong("at")));
        p.addView(sectionTitle("Mensajes" + (mm.size() > 80 ? " (últimos 80)" : ""), null, null));
        if (mm.isEmpty()) p.addView(empty("Todavía no hay mensajes guardados de este cliente"));
        String lastDay = "";
        for (int i = Math.max(0, mm.size() - 80); i < mm.size(); i++) {
            JSONObject m = mm.get(i);
            String d = Store.dayOf(m.optLong("at"));
            if (!d.equals(lastDay)) {
                lastDay = d;
                TextView dl = tv(Store.when(m.optLong("at")).replaceAll(",? ?\\d+:\\d+ [AP]M$", "").replaceAll("^\\d+:\\d+ [AP]M$", "Hoy"), 12, MUT, true);
                dl.setGravity(Gravity.CENTER);
                dl.setPadding(0, dp(8), 0, dp(4));
                p.addView(dl, new LinearLayout.LayoutParams(-1, -2));
            }
            p.addView(bubble(m));
        }

        LinearLayout bottom = vbox();
        bottom.setBackgroundColor(Color.WHITE);
        bottom.setElevation(dp(8));
        bottom.setPadding(dp(8), dp(6), dp(8), dp(8));
        LinearLayout tc = hbox();
        for (JSONObject t : tpls) {
            final String txt = t.optString("text");
            tc.addView(chip(t.optString("title"), false, v -> composeDialog(ch, Store.fill(this, txt, ch.optString("name")))));
        }
        bottom.addView(hscroll(tc));
        LinearLayout ir2 = hbox();
        EditText box = input("Escribe una respuesta…", TXT_MULTI);
        box.setMaxLines(4);
        ((LinearLayout.LayoutParams) box.getLayoutParams()).setMargins(0, dp(4), 0, 0);
        ir2.addView(box, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView send = tv("➤", 22, Color.WHITE, true);
        send.setGravity(Gravity.CENTER);
        send.setBackground(round(WA, 24));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(48), dp(48));
        sl.setMargins(dp(8), dp(4), 0, 0);
        send.setOnClickListener(v -> {
            String t = box.getText().toString().trim();
            if (t.isEmpty()) return;
            sendTo(ch, t);
            box.setText("");
        });
        ir2.addView(send, sl);
        bottom.addView(ir2);
        boolean direct = ChatListener.REPLIES.containsKey(ch.optString("key"));
        bottom.addView(tv(direct ? "⚡ Se envía directo, sin abrir WhatsApp" : "Se abrirá WhatsApp con el mensaje listo", 11, MUT, false));

        LinearLayout whole = vbox();
        whole.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        whole.addView(bottom, new LinearLayout.LayoutParams(-1, -2));
        show(whole, false, null, null);
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }

    View bubble(JSONObject m) {
        String dir = m.optString("dir");
        boolean in = dir.equals("in");
        LinearLayout wrap = hbox();
        wrap.setGravity(in ? Gravity.START : Gravity.END);
        wrap.setPadding(dp(12), dp(3), dp(12), dp(3));
        LinearLayout b = vbox();
        b.setBackground(round(in ? Color.WHITE : dir.equals("auto") ? 0xFFF0E9FF : 0xFFDCF8C6, 14));
        b.setElevation(dp(1));
        b.setPadding(dp(12), dp(8), dp(12), dp(6));
        TextView t = tv(m.optString("text"), 15, TXT, false);
        t.setTextIsSelectable(true);
        b.addView(t);
        TextView tm = tv((dir.equals("auto") ? "🤖 automática · " : "") + Store.time(m.optLong("at")), 11, MUT, false);
        tm.setGravity(Gravity.END);
        b.addView(tm, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        wrap.addView(b, lp);
        b.setMinimumWidth(dp(90));
        t.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.72));
        return wrap;
    }

    void composeDialog(JSONObject ch, String text) {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText e = input("", TXT_MULTI);
        e.setText(text);
        e.setMinLines(3);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("Enviar a " + ch.optString("name")).setView(box)
                .setPositiveButton("Enviar", (dlg, w) -> sendTo(ch, e.getText().toString().trim()))
                .setNeutralButton("Copiar", (dlg, w) -> copy(e.getText().toString()))
                .setNegativeButton("Cancelar", null).show();
    }

    void sendTo(JSONObject ch, String text) {
        if (text.isEmpty()) return;
        if (ChatListener.reply(this, ch.optString("key"), text)) {
            Store.logOut(this, ch.optInt("id"), text, "out");
            toast("Enviado ✅");
            reload();
            refresh();
            return;
        }
        Store.logOut(this, ch.optInt("id"), text, "out");
        reload();
        openWa(ch, text);
    }

    void openWa(JSONObject ch, String text) {
        String ph = ch.optString("phone");
        if (Store.digits(ph).length() >= 10) { launch(Store.waIntent(this, ph, text)); return; }
        if (!text.isEmpty()) copy(text);
        String pkg = Store.waPkg(this);
        Intent i = pkg == null ? null : getPackageManager().getLaunchIntentForPackage(pkg);
        toast(text.isEmpty() ? "Busca el chat de " + ch.optString("name") + " en WhatsApp" : "Mensaje copiado 📋 Pégalo en el chat de " + ch.optString("name"));
        if (i != null) launch(i);
        else toast("Agrega el número de WhatsApp del cliente (✏️) para abrir su chat directo");
    }

    void contactForm(int cid) {
        final JSONObject ch = Store.chatById(chats, cid);
        if (ch == null) { goBack(); return; }
        setHeader("Datos del cliente", ch.optString("name"), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        EditText name = input("Nombre", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        name.setText(ch.optString("name"));
        EditText phone = input("WhatsApp (ej. +1 604 555 1111)", InputType.TYPE_CLASS_PHONE);
        phone.setText(ch.optString("phone"));
        EditText prop = input("Propiedad", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        prop.setText(ch.optString("property"));
        EditText room = input("Cuarto", InputType.TYPE_CLASS_TEXT);
        room.setText(ch.optString("room"));
        EditText notes = input("Notas del cliente", TXT_MULTI);
        notes.setText(ch.optString("notes"));
        TextView type = picker(TYPES, ch.optString("type", TYPES[0]));
        Switch noAuto = new Switch(this);
        noAuto.setText("No enviarle respuesta automática");
        noAuto.setTextColor(TXT);
        noAuto.setPadding(0, dp(12), 0, dp(4));
        noAuto.setChecked(ch.optBoolean("noAuto"));
        c.addView(label("👤", "Nombre (como sale en WhatsApp)", false));
        c.addView(name);
        c.addView(tv("Si lo cambias aquí, también cámbialo igual en los contactos del teléfono para que los mensajes nuevos lleguen a este mismo chat.", 12, MUT, false));
        c.addView(label("📞", "WhatsApp", false));
        c.addView(phone);
        c.addView(label("🏷️", "Tipo de cliente", false));
        c.addView(type);
        c.addView(twoCols(labeled("Propiedad", prop), labeled("Cuarto", room)));
        c.addView(label("📝", "Notas", false));
        c.addView(notes);
        c.addView(noAuto);
        p.addView(c);
        p.addView(button("Guardar", PRI2, v -> {
            String nm = name.getText().toString().trim();
            if (!nm.isEmpty() && !nm.equals(ch.optString("name"))) { Store.put(ch, "name", nm); Store.put(ch, "key", Store.norm(nm)); }
            Store.put(ch, "phone", phone.getText().toString().trim());
            Store.put(ch, "type", (String) type.getTag());
            Store.put(ch, "property", prop.getText().toString().trim());
            Store.put(ch, "room", room.getText().toString().trim());
            Store.put(ch, "notes", notes.getText().toString().trim());
            Store.put(ch, "noAuto", noAuto.isChecked());
            saveChats();
            toast("Guardado ✅");
            goBack();
        }));
        p.addView(button("🗑️  Borrar este chat y sus mensajes", RED, v -> new AlertDialog.Builder(this).setTitle("¿Borrar a " + ch.optString("name") + "?")
                .setMessage("Se borran sus mensajes guardados en la app (no en WhatsApp). Sus casos se conservan.")
                .setPositiveButton("Borrar", (dlg, w) -> {
                    chats.remove(ch);
                    for (int i = msgs.size() - 1; i >= 0; i--) if (msgs.get(i).optInt("cid") == cid) msgs.remove(i);
                    saveChats();
                    Store.save(this, "msgs", msgs);
                    openTab(0);
                }).setNegativeButton("Cancelar", null).show()));
        show(scroll(p), false, null, null);
    }

    // ============================ casos ============================
    int prioIdx(String p) { for (int i = 0; i < PRIOS.length; i++) if (PRIOS[i].equals(p)) return i; return 2; }
    int stIdx(String s) { for (int i = 0; i < STATUS.length; i++) if (STATUS[i].equals(s)) return i; return 0; }

    void casesScreen() {
        int open = 0, urg = 0, mine = 0;
        String me = Store.get(this, "agent", "");
        for (JSONObject cs : cases) {
            if ("Resuelto".equals(cs.optString("status"))) continue;
            open++;
            if (prioIdx(cs.optString("priority")) == 0) urg++;
            if (cs.optString("assigned").equals(me)) mine++;
        }
        setHeader("Casos", open + " abiertos · " + urg + " urgentes", "📋", false);
        LinearLayout p = vbox();
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(8), dp(10), 0);
        String[] fs = {"Abiertos (" + open + ")", "🔴 Urgentes (" + urg + ")", "Para hoy", "Pasados a otros", "Resueltos", "Todos"};
        String[] keys = {"Abiertos", "Urgentes", "Para hoy", "Pasados a otros", "Resueltos", "Todos"};
        for (int i = 0; i < fs.length; i++) {
            final String k = keys[i];
            chips.addView(chip(fs[i], k.equals(caseFilter), v -> { caseFilter = k; casesScreen(); }));
        }
        p.addView(hscroll(chips));
        List<JSONObject> l = new ArrayList<>();
        String today = Store.today();
        for (JSONObject cs : cases) {
            boolean res = "Resuelto".equals(cs.optString("status"));
            if (caseFilter.equals("Abiertos") && res) continue;
            if (caseFilter.equals("Urgentes") && (res || prioIdx(cs.optString("priority")) != 0)) continue;
            if (caseFilter.equals("Pasados a otros") && (res || cs.optString("assigned").isEmpty() || cs.optString("assigned").equals(me))) continue;
            if (caseFilter.equals("Para hoy") && (res || cs.optLong("follow") <= 0 || Store.dayOf(cs.optLong("follow")).compareTo(today) > 0)) continue;
            if (caseFilter.equals("Resueltos") && !res) continue;
            l.add(cs);
        }
        Collections.sort(l, (x, y) -> {
            int a = prioIdx(x.optString("priority")), b = prioIdx(y.optString("priority"));
            if (a != b && !caseFilter.equals("Resueltos")) return Integer.compare(a, b);
            return Long.compare(y.optLong("created"), x.optLong("created"));
        });
        if (l.isEmpty()) p.addView(empty(cases.isEmpty() ? "Todavía no hay casos.\nAbre un caso desde un chat o con «＋ Caso»." : "No hay casos con este filtro"));
        for (JSONObject cs : l) p.addView(caseRow(cs, true));
        show(scroll(p), true, "＋  Caso", () -> open(() -> caseForm(-1, 0)));
    }

    View caseRow(JSONObject cs, boolean showChat) {
        int si = stIdx(cs.optString("status"));
        LinearLayout c = card();
        LinearLayout top = hbox();
        String cat = cs.optString("category");
        TextView ic = tv(cat.isEmpty() ? "📌" : cat.substring(0, cat.indexOf(' ') > 0 ? cat.indexOf(' ') : cat.length()), 20, TXT, false);
        ic.setPadding(0, 0, dp(10), 0);
        top.addView(ic);
        LinearLayout v = vbox();
        TextView t = tv(cs.optString("title"), 15, TXT, true);
        t.setMaxLines(2);
        v.addView(t);
        JSONObject ch = Store.chatById(chats, cs.optInt("cid"));
        String sub = join(" · ", showChat && ch != null ? ch.optString("name") : "", cs.optString("assigned").isEmpty() ? "" : "👤 " + cs.optString("assigned"),
                "hace " + Store.ago(cs.optLong("created")));
        v.addView(tv(sub, 12, MUT, false));
        if (cs.optLong("follow") > 0 && si != 3) {
            boolean late = cs.optLong("follow") < System.currentTimeMillis();
            v.addView(tv((late ? "⏰ Seguimiento vencido: " : "⏰ Seguimiento: ") + Store.when(cs.optLong("follow")), 12, late ? RED : PRI2, true));
        }
        top.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout pills = vbox();
        pills.setGravity(Gravity.END);
        TextView sp = tv(cs.optString("status"), 11, ST_COL[si][0], true);
        sp.setBackground(round(ST_COL[si][1], 20));
        sp.setPadding(dp(8), dp(3), dp(8), dp(3));
        pills.addView(sp);
        TextView pp = tv(cs.optString("priority").split(" ")[0], 14, TXT, false);
        pp.setGravity(Gravity.END);
        pills.addView(pp, new LinearLayout.LayoutParams(-1, -2));
        top.addView(pills);
        c.addView(top);
        final int id = cs.optInt("id");
        c.setOnClickListener(x -> open(() -> caseDetail(id)));
        return c;
    }

    JSONObject caseById(int id) { for (JSONObject cs : cases) if (cs.optInt("id") == id) return cs; return null; }

    String[] agents() {
        String a = Store.get(this, "agent", "");
        List<String> l = new ArrayList<>();
        if (!a.isEmpty()) l.add(a);
        String ops = Store.get(this, "opsName", "");
        if (!ops.isEmpty() && !ops.equals(a)) l.add(ops);
        for (String x : Store.get(this, "others", "").split(",")) if (!x.trim().isEmpty() && !l.contains(x.trim())) l.add(x.trim());
        l.add("Sin asignar");
        return l.toArray(new String[0]);
    }

    void caseForm(int id, int cidStart) {
        final JSONObject old = id < 0 ? null : caseById(id);
        setHeader(old == null ? "Nuevo caso" : "Editar caso", null, null, true);
        final int[] cid = {old != null ? old.optInt("cid") : cidStart};
        LinearLayout p = vbox();
        LinearLayout c = card();
        final TextView who = field("");
        final Runnable showWho = () -> {
            JSONObject ch = Store.chatById(chats, cid[0]);
            who.setText(ch == null ? "👤  Elegir cliente  ▾" : "👤  " + ch.optString("name") + "  ▾");
        };
        showWho.run();
        who.setOnClickListener(v -> {
            List<JSONObject> l = new ArrayList<>(chats);
            Collections.sort(l, (x, y) -> Long.compare(Math.max(y.optLong("lastIn"), y.optLong("lastOut")), Math.max(x.optLong("lastIn"), x.optLong("lastOut"))));
            String[] names = new String[l.size()];
            for (int i = 0; i < names.length; i++) names[i] = l.get(i).optString("name");
            if (names.length == 0) { toast("Primero agrega un cliente en Chats"); return; }
            new AlertDialog.Builder(this).setTitle("Cliente").setItems(names, (dlg, w) -> { cid[0] = l.get(w).optInt("id"); showWho.run(); }).show();
        });
        EditText title = input("Ej. Fuga en el baño del cuarto 3", TXT_CAP);
        EditText desc = input("Detalles (opcional)", TXT_MULTI);
        desc.setMinLines(3);
        TextView cat = picker(CATS, old != null ? old.optString("category") : CATS[0]);
        TextView prio = picker(PRIOS, old != null ? old.optString("priority") : PRIOS[2]);
        TextView ass = picker(agents(), old != null && !old.optString("assigned").isEmpty() ? old.optString("assigned") : Store.get(this, "agent", "Sin asignar"));
        final long[] follow = {old != null ? old.optLong("follow") : 0};
        final TextView ff = field("");
        final Runnable showF = () -> ff.setText(follow[0] > 0 ? "⏰  " + Store.when(follow[0]) : "⏰  Sin recordatorio  (tocar para poner)");
        showF.run();
        ff.setOnClickListener(v -> pickDateTime(follow[0] > 0 ? follow[0] : System.currentTimeMillis() + 86400000L, ms -> { follow[0] = ms; showF.run(); }));
        if (old != null) { title.setText(old.optString("title")); desc.setText(old.optString("desc")); }
        else {
            JSONObject ch = Store.chatById(chats, cid[0]);
            if (ch != null && !ch.optString("lastText").isEmpty() && !ch.optString("lastText").startsWith("Tú:") && !ch.optString("lastText").startsWith("🤖"))
                desc.setText("Mensaje del cliente: " + ch.optString("lastText"));
        }
        c.addView(label("👤", "Cliente", true));
        c.addView(who);
        c.addView(label("📝", "¿Qué pasa?", true));
        c.addView(title);
        c.addView(label("🏷️", "Categoría", false));
        c.addView(cat);
        c.addView(twoCols(labeled("Prioridad", prio), labeled("Responsable", ass)));
        c.addView(labeled("Recordatorio de seguimiento", ff));
        c.addView(label("🗒️", "Detalles", false));
        c.addView(desc);
        p.addView(c);
        p.addView(button("Guardar caso", PRI2, v -> {
            String t = title.getText().toString().trim();
            if (cid[0] <= 0) { toast("Elige el cliente"); return; }
            if (t.isEmpty()) { toast("Escribe de qué se trata el caso"); return; }
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) {
                Store.put(o, "id", Store.nextId(this));
                Store.put(o, "created", System.currentTimeMillis());
                Store.put(o, "status", "Nuevo");
                Store.put(o, "by", Store.get(this, "agent", ""));
                Store.put(o, "log", new JSONArray());
            }
            Store.put(o, "cid", cid[0]);
            Store.put(o, "title", t);
            Store.put(o, "desc", desc.getText().toString().trim());
            Store.put(o, "category", (String) cat.getTag());
            Store.put(o, "priority", (String) prio.getTag());
            Store.put(o, "assigned", "Sin asignar".equals(ass.getTag()) ? "" : (String) ass.getTag());
            Store.put(o, "follow", follow[0]);
            if (old == null) cases.add(o);
            saveCases();
            Store.scheduleFollow(this, o, Store.chatById(chats, cid[0]));
            toast("Caso guardado ✅");
            if (old == null) {
                stack.remove(stack.size() - 1);
                final int nid = o.optInt("id");
                open(() -> caseDetail(nid));
                if (!Store.get(this, "trelloEmail", "").isEmpty() && Store.getB(this, "trelloAsk", true)) {
                    final JSONObject ch2 = Store.chatById(chats, cid[0]);
                    new AlertDialog.Builder(this).setTitle("📤 ¿Enviar a Trello?")
                            .setMessage("Se crea una tarjeta para " + opsName() + " con los datos del caso.")
                            .setPositiveButton("Enviar", (dlg, w) -> sendCaseToTrello(o, ch2))
                            .setNegativeButton("Ahora no", null).show();
                }
            } else goBack();
        }));
        show(scroll(p), false, null, null);
    }

    void addLog(JSONObject cs, String text) {
        JSONArray l = cs.optJSONArray("log");
        if (l == null) { l = new JSONArray(); Store.put(cs, "log", l); }
        JSONObject e = new JSONObject();
        Store.put(e, "at", System.currentTimeMillis());
        Store.put(e, "who", Store.get(this, "agent", ""));
        Store.put(e, "text", text);
        l.put(e);
    }

    void caseDetail(int id) {
        final JSONObject cs = caseById(id);
        if (cs == null) { goBack(); return; }
        final JSONObject ch = Store.chatById(chats, cs.optInt("cid"));
        int si = stIdx(cs.optString("status"));
        setHeader(cs.optString("title"), ch == null ? null : ch.optString("name"), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.setBackground(round(ST_COL[si][1], 16));
        c.addView(tv(cs.optString("status"), 18, ST_COL[si][0], true));
        c.addView(kv("Categoría", cs.optString("category")));
        c.addView(kv("Prioridad", cs.optString("priority")));
        c.addView(kv("Responsable", cs.optString("assigned").isEmpty() ? "Sin asignar" : cs.optString("assigned")));
        c.addView(kv("Abierto", Store.when(cs.optLong("created")) + (cs.optString("by").isEmpty() ? "" : " por " + cs.optString("by"))));
        if (cs.optLong("follow") > 0) c.addView(kv("Seguimiento", Store.when(cs.optLong("follow")), cs.optLong("follow") < System.currentTimeMillis() && si != 3 ? RED : TXT));
        if (cs.optLong("resolved") > 0) c.addView(kv("Resuelto", Store.when(cs.optLong("resolved"))));
        if (!cs.optString("desc").isEmpty()) { c.addView(divider()); c.addView(tv(cs.optString("desc"), 14, TXT, false)); }
        p.addView(c);

        p.addView(sectionTitle("Cambiar estado", null, null));
        LinearLayout sc = hbox();
        sc.setPadding(dp(10), 0, dp(10), 0);
        for (String s : STATUS) {
            sc.addView(chip(s, s.equals(cs.optString("status")), v -> {
                if (s.equals(cs.optString("status"))) return;
                Store.put(cs, "status", s);
                if (s.equals("Resuelto")) { Store.put(cs, "resolved", System.currentTimeMillis()); Store.cancelFollow(this, id); }
                else cs.remove("resolved");
                addLog(cs, "Estado → " + s);
                saveCases();
                if (s.equals("Resuelto") && ch != null) {
                    new AlertDialog.Builder(this).setTitle("✅ Caso resuelto").setMessage("¿Avisarle a " + ch.optString("name") + " por WhatsApp?")
                            .setPositiveButton("Sí, avisar", (dlg, w) -> composeDialog(ch, Store.fill(this, tplText("✅ Caso resuelto",
                                    "Hola {nombre}, te confirmamos que tu solicitud quedó resuelta ✅. Si necesitas algo más, aquí estamos."), ch.optString("name"))))
                            .setNegativeButton("No", null).show();
                }
                refresh();
            }));
        }
        p.addView(hscroll(sc));

        LinearLayout acts = hbox();
        acts.setPadding(dp(10), dp(8), dp(10), 0);
        if (ch != null) acts.addView(smallBtn("💬 Escribirle", WA, v -> open(() -> chatScreen(ch.optInt("id")))), weightLp(1f));
        acts.addView(smallBtn("📤 Compartir / pasar", PRI2, v -> shareCase(cs, ch)), weightLp(1f));
        p.addView(acts);
        boolean sent = cs.optLong("trello") > 0;
        p.addView(button(sent ? "📤  Reenviar a Trello · " + opsName() : "📤  Enviar a Trello · " + opsName(), 0xFF0079BF, v -> sendCaseToTrello(cs, ch)));
        if (sent) {
            TextView tl = tv("✅ Enviado a Trello " + Store.when(cs.optLong("trello")), 13, 0xFF0079BF, true);
            tl.setPadding(dp(18), dp(4), dp(18), 0);
            p.addView(tl);
        }

        p.addView(sectionTitle("Notas y seguimiento", null, null));
        LinearLayout nc = card();
        EditText note = input("Agregar una nota (ej. llamé al plomero, viene mañana 10 AM)", TXT_MULTI);
        nc.addView(note);
        TextView add = tv("＋ Agregar nota", 14, PRI2, true);
        add.setPadding(0, dp(8), 0, 0);
        add.setOnClickListener(v -> {
            String t = note.getText().toString().trim();
            if (t.isEmpty()) return;
            addLog(cs, t);
            if ("Nuevo".equals(cs.optString("status"))) Store.put(cs, "status", "En proceso");
            saveCases();
            refresh();
        });
        nc.addView(add);
        JSONArray log = cs.optJSONArray("log");
        if (log != null) for (int i = log.length() - 1; i >= 0; i--) {
            JSONObject e = log.optJSONObject(i);
            if (e == null) continue;
            nc.addView(divider());
            nc.addView(tv(e.optString("text"), 14, TXT, false));
            nc.addView(tv(Store.when(e.optLong("at")) + (e.optString("who").isEmpty() ? "" : " · " + e.optString("who")), 12, MUT, false));
        }
        p.addView(nc);
        LinearLayout btns = hbox();
        btns.setPadding(dp(8), dp(10), dp(8), 0);
        btns.addView(outline("✏️  Editar", PRI2, v -> open(() -> caseForm(id, 0))), weightLp(1f));
        btns.addView(outline("🗑️  Eliminar", RED, v -> new AlertDialog.Builder(this).setTitle("¿Eliminar este caso?")
                .setPositiveButton("Eliminar", (dlg, w) -> { Store.cancelFollow(this, id); cases.remove(cs); saveCases(); goBack(); })
                .setNegativeButton("Cancelar", null).show()), weightLp(1f));
        p.addView(btns);
        show(scroll(p), false, null, null);
    }

    // ============================ Trello ============================
    String opsName() { String n = Store.get(this, "opsName", ""); return n.isEmpty() ? "Operaciones" : n; }

    boolean trelloReady() {
        if (Store.get(this, "trelloEmail", "").contains("@")) return true;
        new AlertDialog.Builder(this).setTitle("Falta el correo del tablero")
                .setMessage("En Trello abre el tablero de operaciones → Menú (⋯) → Configuración → «Correo al tablero», copia la dirección y pégala en Más → Ajustes → Trello de Operaciones.")
                .setPositiveButton("Ir a Ajustes", (dlg, w) -> open(() -> settings(false)))
                .setNegativeButton("Cancelar", null).show();
        return false;
    }

    String trelloTags(String priority) {
        StringBuilder t = new StringBuilder();
        int pi = prioIdx(priority);
        if (pi == 0) t.append(" #red");
        else if (pi == 1) t.append(" #orange");
        String u = Store.get(this, "trelloUser", "");
        if (!u.isEmpty()) t.append(" @").append(u);
        return t.toString();
    }

    void sendCaseToTrello(JSONObject cs, JSONObject ch) {
        if (!trelloReady()) return;
        String cat = cs.optString("category");
        String icon = cat.isEmpty() ? "📌" : cat.substring(0, cat.indexOf(' ') > 0 ? cat.indexOf(' ') : cat.length());
        String where = ch == null ? "" : join(" · ", ch.optString("property"), ch.optString("room").isEmpty() ? "" : "Cuarto " + ch.optString("room"));
        String subject = icon + " " + cs.optString("title") + (ch != null ? " – " + ch.optString("name") : "") + (where.isEmpty() ? "" : " (" + where + ")")
                + trelloTags(cs.optString("priority"));
        StringBuilder b = new StringBuilder();
        b.append("**Categoría:** ").append(cat.replaceAll("^\\S+\\s", "")).append("\n");
        b.append("**Prioridad:** ").append(cs.optString("priority").replaceAll("^\\S+\\s", "")).append("\n");
        b.append("**Estado:** ").append(cs.optString("status")).append("\n");
        if (ch != null) {
            b.append("**Cliente:** ").append(ch.optString("name")).append(ch.optString("type").equals("Sin clasificar") ? "" : " (" + ch.optString("type") + ")").append("\n");
            if (!ch.optString("phone").isEmpty()) b.append("**WhatsApp:** ").append(ch.optString("phone")).append("\n");
            if (!where.isEmpty()) b.append("**Propiedad:** ").append(where).append("\n");
        }
        b.append("**Abierto:** ").append(Store.when(cs.optLong("created"))).append(cs.optString("by").isEmpty() ? "" : " por " + cs.optString("by")).append("\n");
        if (cs.optLong("follow") > 0) b.append("**Seguimiento:** ").append(Store.when(cs.optLong("follow"))).append("\n");
        if (!cs.optString("desc").isEmpty()) b.append("\n").append(cs.optString("desc")).append("\n");
        JSONArray log = cs.optJSONArray("log");
        if (log != null && log.length() > 0) {
            b.append("\n**Notas:**\n");
            for (int i = 0; i < log.length(); i++) {
                JSONObject e = log.optJSONObject(i);
                if (e != null) b.append("- ").append(e.optString("text")).append(" _(").append(Store.when(e.optLong("at"))).append(")_\n");
            }
        }
        b.append("\n— Enviado desde Clientes Amigo Renta por ").append(Store.get(this, "agent", ""));
        if (sendEmail(Store.get(this, "trelloEmail", ""), subject, b.toString(), null, null)) {
            Store.put(cs, "trello", System.currentTimeMillis());
            addLog(cs, "Enviado a Trello (" + opsName() + ")");
            saveCases();
        }
    }

    void sendReportToTrello() {
        if (!trelloReady()) return;
        List<JSONObject> open = new ArrayList<>();
        for (JSONObject c : cases) if (!"Resuelto".equals(c.optString("status"))) open.add(c);
        Collections.sort(open, (x, y) -> Integer.compare(prioIdx(x.optString("priority")), prioIdx(y.optString("priority"))));
        StringBuilder b = new StringBuilder("**Casos abiertos: ").append(open.size()).append("**\n\n");
        for (JSONObject c : open) {
            JSONObject ch = Store.chatById(chats, c.optInt("cid"));
            b.append("- ").append(c.optString("priority").split(" ")[0]).append(" **").append(c.optString("title")).append("**");
            if (ch != null) b.append(" – ").append(ch.optString("name"));
            if (ch != null && !ch.optString("property").isEmpty()) b.append(" (").append(ch.optString("property"))
                    .append(ch.optString("room").isEmpty() ? "" : " · Cuarto " + ch.optString("room")).append(")");
            b.append(" · ").append(c.optString("status")).append(c.optString("assigned").isEmpty() ? "" : " · " + c.optString("assigned")).append("\n");
        }
        if (open.isEmpty()) b.append("✅ No hay casos abiertos.\n");
        Uri file = saveXlsxUri();
        if (file != null) b.append("\n📎 El Excel adjunto tiene todos los casos, clientes y mensajes.\n");
        b.append("\n— Clientes Amigo Renta · ").append(Store.get(this, "agent", ""));
        String subject = "📊 Reporte de atención al cliente · " + Store.when(System.currentTimeMillis()) + trelloTags("");
        sendEmail(Store.get(this, "trelloEmail", ""), subject, b.toString(), file,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    }

    Uri saveXlsxUri() {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "Clientes_Amigo_Renta_" + Store.today() + "_" + (System.currentTimeMillis() % 100000) + ".xlsx");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Reportes");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return null;
            try (OutputStream os = getContentResolver().openOutputStream(u)) { writeXlsx(os); }
            return u;
        } catch (Exception e) { return null; }
    }

    boolean sendEmail(String to, String subject, String body, Uri file, String mime) {
        Intent i;
        if (file != null) {
            i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, file);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setSelector(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")));
        } else {
            i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        }
        i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
        i.putExtra(Intent.EXTRA_SUBJECT, subject);
        i.putExtra(Intent.EXTRA_TEXT, body);
        try {
            startActivity(Intent.createChooser(i, "Enviar a Trello con…"));
            toast("Envía el correo y la tarjeta aparecerá en Trello 📤");
            return true;
        } catch (Exception e) {
            toast("No hay una app de correo instalada");
            return false;
        }
    }

    String tplText(String title, String def) {
        for (JSONObject t : tpls) if (t.optString("title").equals(title)) return t.optString("text");
        return def;
    }

    String caseText(JSONObject cs, JSONObject ch) {
        StringBuilder b = new StringBuilder("📋 *Caso: ").append(cs.optString("title")).append("*\n");
        if (ch != null) {
            b.append("👤 ").append(ch.optString("name"));
            if (!ch.optString("phone").isEmpty()) b.append(" · ").append(ch.optString("phone"));
            b.append("\n");
            String w = join(" · ", ch.optString("property"), ch.optString("room").isEmpty() ? "" : "Cuarto " + ch.optString("room"));
            if (!w.isEmpty()) b.append("🏠 ").append(w).append("\n");
        }
        b.append(cs.optString("category")).append(" · ").append(cs.optString("priority")).append("\n");
        b.append("Estado: ").append(cs.optString("status")).append("\n");
        if (!cs.optString("desc").isEmpty()) b.append("\n").append(cs.optString("desc")).append("\n");
        JSONArray log = cs.optJSONArray("log");
        if (log != null && log.length() > 0) {
            b.append("\nNotas:\n");
            for (int i = Math.max(0, log.length() - 5); i < log.length(); i++) {
                JSONObject e = log.optJSONObject(i);
                if (e != null) b.append("• ").append(e.optString("text")).append(" (").append(Store.when(e.optLong("at"))).append(")\n");
            }
        }
        b.append("\n— Clientes Amigo Renta");
        return b.toString();
    }

    void shareCase(JSONObject cs, JSONObject ch) {
        String[] ag = agents();
        new AlertDialog.Builder(this).setTitle("¿A quién se lo pasas?").setItems(ag, (dlg, w) -> {
            String a = ag[w];
            if (!a.equals("Sin asignar")) {
                Store.put(cs, "assigned", a);
                addLog(cs, "Asignado a " + a);
                saveCases();
            }
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, caseText(cs, ch));
            launch(Intent.createChooser(i, "Enviar caso"));
            refresh();
        }).show();
    }

    // ============================ respuestas rápidas ============================
    void tplScreen() {
        setHeader("Respuestas rápidas", tpls.size() + " plantillas", "⚡", false);
        LinearLayout p = vbox();
        TextView h = tv("Puedes usar: {nombre} (nombre del cliente), {horario}, {correo_pagos}, {telefono}, {agente}.", 13, MUT, false);
        h.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(h);
        for (int i = 0; i < tpls.size(); i++) {
            final int k = i;
            JSONObject t = tpls.get(i);
            LinearLayout c = card();
            c.addView(tv(t.optString("title"), 16, TXT, true));
            TextView tx = tv(Store.fill(this, t.optString("text"), "María"), 14, MUT, false);
            tx.setMaxLines(4);
            tx.setEllipsize(TextUtils.TruncateAt.END);
            c.addView(tx);
            c.setOnClickListener(v -> tplForm(k));
            p.addView(c);
        }
        show(scroll(p), true, "＋  Respuesta", () -> tplForm(-1));
    }

    void tplForm(int idx) {
        final JSONObject old = idx < 0 ? null : tpls.get(idx);
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText t = input("Título (ej. 🏠 Requisitos)", InputType.TYPE_CLASS_TEXT);
        EditText x = input("Texto del mensaje", TXT_MULTI);
        x.setMinLines(5);
        if (old != null) { t.setText(old.optString("title")); x.setText(old.optString("text")); }
        box.addView(t);
        box.addView(x);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(old == null ? "Nueva respuesta" : "Editar respuesta").setView(box)
                .setPositiveButton("Guardar", (dlg, w) -> {
                    if (t.getText().toString().trim().isEmpty() || x.getText().toString().trim().isEmpty()) return;
                    JSONObject o = old != null ? old : new JSONObject();
                    if (old == null) { Store.put(o, "id", Store.nextId(this)); tpls.add(o); }
                    Store.put(o, "title", t.getText().toString().trim());
                    Store.put(o, "text", x.getText().toString().trim());
                    Store.save(this, "tpls", tpls);
                    refresh();
                }).setNegativeButton("Cancelar", null);
        if (old != null) b.setNeutralButton("Eliminar", (dlg, w) -> { tpls.remove(old); Store.save(this, "tpls", tpls); refresh(); });
        b.show();
    }

    // ============================ más / ajustes ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow(listenerOn() ? "🟢" : "🔴", "Conexión con WhatsApp", listenerOn() ? "Activa" : "Desactivada · toca para activar", v -> open(this::connectScreen)));
        c.addView(divider());
        c.addView(menuRow("🤖", "Respuesta automática y horario", Store.getB(this, "autoReply", true) ? "Activa" : "Apagada", v -> open(() -> settings(false))));
        c.addView(divider());
        c.addView(menuRow("📤", "Reporte a Trello · " + opsName(), "Casos abiertos + Excel en una tarjeta", v -> sendReportToTrello()));
        c.addView(divider());
        c.addView(menuRow("📊", "Exportar a Excel", "Casos, clientes y mensajes", v -> exportXlsx()));
        c.addView(divider());
        c.addView(menuRow("💾", "Copia de seguridad", "Guardar, enviar o restaurar tus datos", v -> Backup.menu(this)));
        c.addView(divider());
        c.addView(menuRow("⚙️", "Ajustes", "Tu nombre, horario, correo de pagos, Trello", v -> open(() -> settings(false))));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "Clientes Amigo Renta · versión 1.3", null));
        p.addView(c);
        show(scroll(p), true, null, null);
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void connectScreen() {
        boolean on = listenerOn();
        setHeader("Conexión con WhatsApp", on ? "Activa" : "Desactivada", null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.setBackground(round(on ? 0xFFE3F6E8 : 0xFFFDE6E6, 16));
        c.addView(tv(on ? "🟢  Conectada" : "🔴  Desactivada", 18, on ? 0xFF15803D : 0xFFB91C1C, true));
        c.addView(tv("La app lee solo las notificaciones de WhatsApp Business de este teléfono (puedes cambiarlo en Ajustes): guarda cada mensaje, te muestra quién espera respuesta, "
                + "y te deja responder directo o con respuesta automática fuera de horario. No lee chats que ya estaban antes.", 14, TXT, false));
        p.addView(c);
        LinearLayout s = card();
        s.addView(tv("Pasos", 16, TXT, true));
        s.addView(tv("1. Toca «Abrir ajustes» y activa «Clientes Amigo Renta».\n"
                + "2. Si sale «Ajuste restringido»: Ajustes → Aplicaciones → Clientes Amigo Renta → ⋮ (arriba) → «Permitir ajustes restringidos», y vuelve al paso 1.\n"
                + "3. En WhatsApp Business: Ajustes → Notificaciones → deja activadas las notificaciones de mensajes.\n"
                + "4. No silencies los chats de clientes: los chats silenciados no generan notificación.", 14, TXT, false));
        p.addView(s);
        p.addView(button(on ? "Revisar ajustes" : "Abrir ajustes", on ? PRI2 : RED, v -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { toast("Abre Ajustes → Notificaciones → Acceso a notificaciones"); }
        }));
        show(scroll(p), false, null, null);
    }

    void settings(boolean first) {
        setHeader(first ? "¡Bienvenida!" : "Ajustes", first ? "Configura tu app" : null, first ? "💬" : null, !first);
        LinearLayout p = vbox();
        LinearLayout a = card();
        a.addView(tv("👤  Tus datos", 16, TXT, true));
        EditText ag = input("Tu nombre", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        ag.setText(Store.get(this, "agent", ""));
        EditText others = input("Ej. Mantenimiento, Limpieza (opcional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        others.setText(Store.get(this, "others", ""));
        a.addView(labeled("Tu nombre", ag));
        a.addView(labeled("A quién más le pasas casos (separados por coma)", others));
        p.addView(a);

        LinearLayout h = card();
        h.addView(tv("🕘  Horario de atención (hora de Vancouver)", 16, TXT, true));
        final String[] open = {Store.get(this, "open", "09:00")}, close = {Store.get(this, "close", "18:00")};
        final TextView of = field(Store.hm12(open[0])), cf = field(Store.hm12(close[0]));
        of.setOnClickListener(v -> pickTime(open[0], hm -> { open[0] = hm; of.setText(Store.hm12(hm)); }));
        cf.setOnClickListener(v -> pickTime(close[0], hm -> { close[0] = hm; cf.setText(Store.hm12(hm)); }));
        h.addView(twoCols(labeled("Abre", of), labeled("Cierra", cf)));
        final char[] days = Store.get(this, "days", "1111110").toCharArray();
        String[] dn = {"L", "M", "M", "J", "V", "S", "D"};
        LinearLayout dr = hbox();
        dr.setPadding(0, dp(8), 0, 0);
        final TextView[] dc = new TextView[7];
        for (int i = 0; i < 7; i++) {
            final int k = i;
            dc[i] = chip(dn[i], days[i] == '1', v -> { days[k] = days[k] == '1' ? '0' : '1'; styleChip(dc[k], days[k] == '1'); });
            dr.addView(dc[i]);
        }
        h.addView(dr);
        p.addView(h);

        LinearLayout srcC = card();
        srcC.addView(tv("📲  ¿De qué WhatsApp leo los mensajes?", 16, TXT, true));
        final String[] srcOpts = {"Solo WhatsApp Business", "Solo WhatsApp personal", "Los dos"};
        String cur = Store.get(this, "waSource", "business");
        TextView src = picker(srcOpts, cur.equals("personal") ? srcOpts[1] : cur.equals("ambos") ? srcOpts[2] : srcOpts[0]);
        srcC.addView(src);
        srcC.addView(tv("Recomendado: solo WhatsApp Business, para que no entren tus chats personales.", 12, MUT, false));
        TextView clean = tv("🧹 Borrar los chats capturados y empezar de cero", 14, RED, true);
        clean.setPadding(0, dp(12), 0, 0);
        clean.setOnClickListener(v -> cleanChats());
        srcC.addView(clean);
        p.addView(srcC);

        LinearLayout r = card();
        r.addView(tv("🤖  Respuesta automática fuera de horario", 16, TXT, true));
        Switch auto = new Switch(this);
        auto.setText("Activada");
        auto.setTextColor(TXT);
        auto.setTextSize(15);
        auto.setPadding(0, dp(8), 0, dp(4));
        auto.setChecked(Store.getB(this, "autoReply", true));
        r.addView(auto);
        EditText txt = input("Mensaje", TXT_MULTI);
        txt.setText(Store.get(this, "autoText", Store.DEFAULT_AUTO));
        txt.setMinLines(4);
        r.addView(label("💬", "Mensaje automático", false));
        r.addView(txt);
        final String[] gaps = {"4", "8", "12", "24"};
        TextView gap = picker(gaps, String.valueOf(Store.getI(this, "autoGap", 12)));
        r.addView(labeled("No repetir al mismo cliente antes de (horas)", gap));
        Switch groups = new Switch(this);
        groups.setText("Guardar también mensajes de grupos");
        groups.setTextColor(TXT);
        groups.setPadding(0, dp(12), 0, dp(4));
        groups.setChecked(Store.getB(this, "groups", false));
        r.addView(groups);
        p.addView(r);

        LinearLayout o = card();
        o.addView(tv("📌  Datos para las respuestas", 16, TXT, true));
        EditText pay = input("Ej. pagos@amigorenta.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        pay.setText(Store.get(this, "payEmail", ""));
        EditText office = input("+1 604-767-8650", InputType.TYPE_CLASS_PHONE);
        office.setText(Store.get(this, "officePhone", "+1 604-767-8650"));
        final String[] waOpts = {"WhatsApp Business", "WhatsApp normal"};
        TextView wa = picker(waOpts, Store.get(this, "waApp", "business").equals("business") ? waOpts[0] : waOpts[1]);
        o.addView(labeled("Correo para e-Transfer {correo_pagos}", pay));
        o.addView(twoCols(labeled("Teléfono {telefono}", office), labeled("Abrir chats con", wa)));
        p.addView(o);

        LinearLayout tr = card();
        tr.addView(tv("📤  Trello de Operaciones", 16, TXT, true));
        EditText tEmail = input("Ej. operaciones+abc123@boards.trello.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        tEmail.setText(Store.get(this, "trelloEmail", ""));
        EditText tName = input("Ej. Alex", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        tName.setText(Store.get(this, "opsName", ""));
        EditText tUser = input("Ej. alexrodriguez (opcional)", InputType.TYPE_CLASS_TEXT);
        tUser.setText(Store.get(this, "trelloUser", ""));
        Switch tAsk = new Switch(this);
        tAsk.setText("Preguntar si lo envío cada vez que abro un caso");
        tAsk.setTextColor(TXT);
        tAsk.setPadding(0, dp(12), 0, dp(4));
        tAsk.setChecked(Store.getB(this, "trelloAsk", true));
        tr.addView(labeled("Correo del tablero (Email-to-board)", tEmail));
        tr.addView(tv("En Trello: abre el tablero → Menú (⋯) → Configuración → «Correo al tablero». Copia esa dirección aquí. Ahí eliges en qué lista llegan las tarjetas.", 12, MUT, false));
        tr.addView(twoCols(labeled("Encargada/o de operaciones", tName), labeled("Su usuario de Trello", tUser)));
        tr.addView(tAsk);
        p.addView(tr);
        p.addView(button(first ? "Empezar" : "Guardar", PRI2, v -> {
            Store.putS(this, "trelloEmail", tEmail.getText().toString().trim());
            Store.putS(this, "opsName", tName.getText().toString().trim());
            Store.putS(this, "trelloUser", tUser.getText().toString().trim().replace("@", ""));
            Store.putB(this, "trelloAsk", tAsk.isChecked());
            String me = ag.getText().toString().trim();
            if (me.isEmpty()) { toast("Escribe tu nombre"); return; }
            Store.putS(this, "agent", me);
            Store.putS(this, "others", others.getText().toString().trim());
            Store.putS(this, "open", open[0]);
            Store.putS(this, "close", close[0]);
            Store.putS(this, "days", new String(days));
            Store.putB(this, "autoReply", auto.isChecked());
            Store.putS(this, "autoText", txt.getText().toString().trim().isEmpty() ? Store.DEFAULT_AUTO : txt.getText().toString().trim());
            Store.putI(this, "autoGap", Integer.parseInt((String) gap.getTag()));
            Store.putB(this, "groups", groups.isChecked());
            String sv = (String) src.getTag();
            Store.putS(this, "waSource", sv.equals(srcOpts[1]) ? "personal" : sv.equals(srcOpts[2]) ? "ambos" : "business");
            Store.putS(this, "payEmail", pay.getText().toString().trim());
            Store.putS(this, "officePhone", office.getText().toString().trim());
            Store.putS(this, "waApp", ((String) wa.getTag()).equals(waOpts[0]) ? "business" : "normal");
            toast("Guardado ✅");
            if (first) { openTab(0); if (!listenerOn()) open(this::connectScreen); }
            else goBack();
        }));
        show(scroll(p), !first, null, null);
    }

    void cleanChats() {
        int personal = 0;
        for (JSONObject ch : chats) if ("personal".equals(ch.optString("src"))) personal++;
        final int pc = personal;
        String[] opts = pc > 0
                ? new String[]{"Borrar solo los del WhatsApp personal (" + pc + ")", "Borrar TODOS los chats capturados"}
                : new String[]{"Borrar TODOS los chats capturados"};
        new AlertDialog.Builder(this).setTitle("🧹 Limpiar chats")
                .setItems(opts, (dlg, w) -> {
                    final boolean onlyPersonal = pc > 0 && w == 0;
                    new AlertDialog.Builder(this).setTitle("¿Seguro?")
                            .setMessage((onlyPersonal ? "Se borran los chats que vinieron del WhatsApp personal" : "Se borran todos los chats y mensajes guardados")
                                    + ". Los clientes que tienen casos se conservan, igual que los casos y las respuestas rápidas.\n\nTe recomiendo hacer antes una copia de seguridad.")
                            .setPositiveButton("Borrar", (d2, w2) -> {
                                List<Integer> keep = new ArrayList<>();
                                for (JSONObject cs : cases) keep.add(cs.optInt("cid"));
                                List<Integer> gone = new ArrayList<>();
                                for (int i = chats.size() - 1; i >= 0; i--) {
                                    JSONObject ch = chats.get(i);
                                    if (onlyPersonal && !"personal".equals(ch.optString("src"))) continue;
                                    if (keep.contains(ch.optInt("id"))) continue;
                                    gone.add(ch.optInt("id"));
                                    chats.remove(i);
                                }
                                for (int i = msgs.size() - 1; i >= 0; i--) {
                                    JSONObject m = msgs.get(i);
                                    if (gone.contains(m.optInt("cid"))) msgs.remove(i);
                                }
                                saveChats();
                                Store.save(this, "msgs", msgs);
                                toast(gone.size() + " chats borrados");
                                refresh();
                            }).setNegativeButton("Cancelar", null).show();
                }).show();
    }

    // ============================ Excel ============================
    void exportXlsx() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        i.putExtra(Intent.EXTRA_TITLE, "Clientes_Amigo_Renta_" + Store.today() + ".xlsx");
        try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (Backup.onResult(this, rq, rs, data, this::afterRestore)) return;
        if (rq == REQ_EXPORT && rs == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                writeXlsx(os);
                toast("Excel guardado ✅");
            } catch (Exception e) { toast("No se pudo guardar el archivo"); }
        }
    }

    void afterRestore() {
        Store.scheduleAllFollowups(this);
        recreate();
    }

    void writeXlsx(OutputStream os) throws Exception {
        List<String> names = new ArrayList<>();
        List<List<List<Object>>> sheets = new ArrayList<>();
        List<int[]> widths = new ArrayList<>();
        List<List<Object>> cs = new ArrayList<>();
        cs.add(row("Abierto", "Cliente", "Teléfono", "Propiedad", "Cuarto", "Caso", "Categoría", "Prioridad", "Estado", "Responsable",
                "Seguimiento", "Resuelto", "Horas hasta resolver", "Detalles", "Última nota"));
        List<JSONObject> sc = new ArrayList<>(cases);
        Collections.sort(sc, (x, y) -> Long.compare(y.optLong("created"), x.optLong("created")));
        for (JSONObject c : sc) {
            JSONObject ch = Store.chatById(chats, c.optInt("cid"));
            JSONArray log = c.optJSONArray("log");
            String lastNote = log != null && log.length() > 0 ? log.optJSONObject(log.length() - 1).optString("text") : "";
            Object hrs = c.optLong("resolved") > 0 ? (Object) (Math.round((c.optLong("resolved") - c.optLong("created")) / 360000.0) / 10.0) : "";
            cs.add(row(Store.excelDate(c.optLong("created")), ch == null ? "" : ch.optString("name"), ch == null ? "" : ch.optString("phone"),
                    ch == null ? "" : ch.optString("property"), ch == null ? "" : ch.optString("room"), c.optString("title"),
                    c.optString("category").replaceAll("^\\S+\\s", ""), c.optString("priority").replaceAll("^\\S+\\s", ""), c.optString("status"),
                    c.optString("assigned"), Store.excelDate(c.optLong("follow")), Store.excelDate(c.optLong("resolved")), hrs, c.optString("desc"), lastNote));
        }
        names.add("Casos"); sheets.add(cs); widths.add(new int[]{17, 24, 16, 26, 9, 32, 22, 10, 16, 14, 17, 17, 12, 40, 40});
        List<List<Object>> cl = new ArrayList<>();
        cl.add(row("Cliente", "Teléfono", "Tipo", "Propiedad", "Cuarto", "Primer contacto", "Último mensaje", "Estado", "Casos abiertos", "Notas"));
        for (JSONObject ch : chats) {
            int st = Store.state(ch);
            cl.add(row(ch.optString("name"), ch.optString("phone"), ch.optString("type"), ch.optString("property"), ch.optString("room"),
                    Store.excelDate(ch.optLong("created")), Store.excelDate(Math.max(ch.optLong("lastIn"), ch.optLong("lastOut"))),
                    CH_NAME[st], openCases(ch.optInt("id")), ch.optString("notes")));
        }
        names.add("Clientes"); sheets.add(cl); widths.add(new int[]{26, 16, 18, 26, 9, 17, 17, 18, 12, 40});
        List<List<Object>> ms = new ArrayList<>();
        ms.add(row("Fecha", "Cliente", "De", "Mensaje"));
        long since = System.currentTimeMillis() - 31L * 86400000L;
        for (JSONObject m : msgs) {
            if (m.optLong("at") < since) continue;
            JSONObject ch = Store.chatById(chats, m.optInt("cid"));
            String d = m.optString("dir");
            ms.add(row(Store.excelDate(m.optLong("at")), ch == null ? "" : ch.optString("name"),
                    d.equals("in") ? "Cliente" : d.equals("auto") ? "Automática" : "Amigo Renta", m.optString("text")));
        }
        names.add("Mensajes 30 días"); sheets.add(ms); widths.add(new int[]{17, 24, 12, 80});
        int[] byCat = new int[CATS.length];
        int open = 0, res = 0;
        for (JSONObject c : cases) {
            for (int i = 0; i < CATS.length; i++) if (CATS[i].equals(c.optString("category"))) byCat[i]++;
            if ("Resuelto".equals(c.optString("status"))) res++; else open++;
        }
        List<List<Object>> sm = new ArrayList<>();
        sm.add(row("Resumen", "Cantidad"));
        sm.add(row("Clientes", chats.size()));
        sm.add(row("Casos abiertos", open));
        sm.add(row("Casos resueltos", res));
        for (int i = 0; i < CATS.length; i++) sm.add(row(CATS[i].replaceAll("^\\S+\\s", ""), byCat[i]));
        names.add(0, "Resumen"); sheets.add(0, sm); widths.add(0, new int[]{32, 12});
        writeBook(os, names, sheets, widths);
    }

    void writeBook(OutputStream os, List<String> names, List<List<List<Object>>> sheets, List<int[]> widths) throws Exception {
        ZipOutputStream z = new ZipOutputStream(os);
        String ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        String pk = "http://schemas.openxmlformats.org/package/2006/relationships";
        String hd = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
        StringBuilder ct = new StringBuilder(hd + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        StringBuilder wb = new StringBuilder(hd + "<workbook xmlns=\"" + ns + "\" xmlns:r=\"" + rel + "\"><sheets>");
        StringBuilder wr = new StringBuilder(hd + "<Relationships xmlns=\"" + pk + "\">");
        for (int i = 0; i < names.size(); i++) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            wb.append("<sheet name=\"").append(xml(names.get(i))).append("\" sheetId=\"").append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
            wr.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(rel).append("/worksheet\" Target=\"worksheets/sheet").append(i + 1).append(".xml\"/>");
        }
        ct.append("</Types>");
        wb.append("</sheets></workbook>");
        wr.append("<Relationship Id=\"rId").append(names.size() + 1).append("\" Type=\"").append(rel).append("/styles\" Target=\"styles.xml\"/></Relationships>");
        zput(z, "[Content_Types].xml", ct.toString());
        zput(z, "_rels/.rels", hd + "<Relationships xmlns=\"" + pk + "\"><Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        zput(z, "xl/workbook.xml", wb.toString());
        zput(z, "xl/_rels/workbook.xml.rels", wr.toString());
        zput(z, "xl/styles.xml", hd + "<styleSheet xmlns=\"" + ns + "\">"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0D3B7A\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        for (int i = 0; i < names.size(); i++) zput(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(ns, sheets.get(i), widths.get(i)));
        z.finish();
    }

    static List<Object> row(Object... cells) { List<Object> r = new ArrayList<>(); Collections.addAll(r, cells); return r; }

    static void zput(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static String colName(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    static String xml(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t' && ch != '\r') b.append(' ');
            else b.append(ch);
        }
        return b.toString();
    }

    static String sheetXml(String ns, List<List<Object>> rows, int[] widths) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        s.append("<worksheet xmlns=\"").append(ns).append("\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>");
        for (int i = 0; i < widths.length; i++)
            s.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            s.append("<row r=\"").append(r + 1).append("\">");
            List<Object> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                Object v = row.get(c);
                String ref = colName(c) + (r + 1);
                if (v instanceof Number && r > 0) s.append("<c r=\"").append(ref).append("\"><v>").append(v).append("</v></c>");
                else {
                    String str = v == null ? "" : v.toString();
                    if (str.isEmpty() && r > 0) continue;
                    s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(r == 0 ? " s=\"1\"" : "")
                            .append("><is><t xml:space=\"preserve\">").append(xml(str)).append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    // ============================ utilidades ============================
    View kv(String k, String v) { return kv(k, v, TXT); }

    View kv(String k, String v, int color) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(4), 0, dp(4));
        r.addView(tv(k, 14, MUT, false), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView t = tv(v, 15, color, true);
        t.setGravity(Gravity.END);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1.4f));
        return r;
    }

    void pickDateTime(long base, java.util.function.LongConsumer cb) {
        Calendar c = Store.cal();
        c.setTimeInMillis(base);
        new DatePickerDialog(this, (dpk, y, m, d) -> {
            String iso = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d);
            pickTime(String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)),
                    hm -> cb.accept(Store.millisAt(iso, hm)));
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    void pickTime(String hm, Cb cb) {
        int h = 9, mi = 0;
        try { String[] x = hm.split(":"); h = Integer.parseInt(x[0]); mi = Integer.parseInt(x[1]); } catch (Exception e) { }
        new TimePickerDialog(this, (tp, hh, mm) -> cb.on(String.format(Locale.US, "%02d:%02d", hh, mm)), h, mi, false).show();
    }

    static String join(String sep, String... parts) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    TextView smallBtn(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 13, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 12, color));
        b.setPadding(dp(6), dp(11), dp(6), dp(11));
        b.setMaxLines(1);
        b.setOnClickListener(l);
        return b;
    }

    void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Mensaje", text));
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

}
