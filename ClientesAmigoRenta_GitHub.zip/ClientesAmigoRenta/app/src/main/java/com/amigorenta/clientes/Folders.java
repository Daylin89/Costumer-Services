package com.amigorenta.clientes;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Carpetas de la bandeja de mensajes y clasificación automática por palabras clave. */
public class Folders {
    static final String OPS = "ops", ROOMS = "rooms", PAY = "pay", OTHER = "other";
    static final String[] IDS = {OPS, ROOMS, PAY, OTHER};
    static final String[] ICON = {"🔧", "🏠", "💲", "📌"};
    static final String[] NAME = {"Operaciones", "Habitaciones disponibles", "Pagos / renta", "Otros"};
    static final String[] SHORT = {"Operaciones", "Habitaciones", "Pagos", "Otros"};
    static final int[] COLOR = {0xFFEA580C, 0xFF16A34A, 0xFF1565C0, 0xFF6B7585};
    static final int[] SOFT = {0xFFFFEDD5, 0xFFDCFCE7, 0xFFE4ECFF, 0xFFEEF1F5};

    static int idx(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return i;
        return 3;
    }

    static String label(String id) { int i = idx(id); return ICON[i] + " " + NAME[i]; }

    // Palabras (sin acentos, en mayúsculas). Se buscan al inicio de palabra, así «REPAR» encuentra «reparar», «reparación»…
    static final String[] W_OPS = {"REPAR", "ARREGL", "ROTO", "ROTA ", "ROMPI", "DANAD", "DANO", "FUGA", "GOTEA", "GOTERA", "SALIDERO", "TUPID", "TAPAD", "DESTAP",
            "AGUA CALIENTE", "NO HAY AGUA", "CALEFACC", "CALENTADOR", "HEATER", "HEAT", "NO HAY LUZ", "SIN LUZ", "BOMBILLO", "BOMBILLA", "FOCO", "ENCHUFE", "BREAKER",
            "INODORO", "TOILET", "BANO", "DUCHA", "LAVAMANOS", "FREGADERO", "LLAVE DEL", "GRIFO", "TUBERIA", "PLOMER", "ELECTRICISTA",
            "LAVADORA", "SECADORA", "WASHER", "DRYER", "NEVERA", "REFRI", "FRIDGE", "ESTUFA", "HORNO", "STOVE", "MICROONDAS",
            "CERRADURA", "PUERTA", "VENTANA", "PERSIANA", "CAMA ", "COLCHON", "MUEBLE", "SILLA", "CUCARACH", "RATON", "RATA", "PLAGA", "CHINCHE", "BED BUG",
            "MOHO", "MOLD", "HUMEDAD", "OLOR", "LIMPIEZA", "LIMPIAR", "BASURA", "GARBAGE", "WIFI", "WI FI", "INTERNET", "ROUTER", "MANTENIMIENTO",
            "REPAIR", "BROKEN", "LEAK", "FIX", "NOT WORKING", "NO FUNCIONA", "NO SIRVE", "NO PRENDE", "NO ENCIENDE", "ALARMA", "DETECTOR", "HUMO", "EXTERMIN",
            "ME QUEDE AFUERA", "PERDI LA LLAVE", "LOCKED OUT", "RUIDO", "NOISE", "VECINO", "ME MUDO ", "MOVE OUT", "ENTREGO", "INSPECCION"};
    static final String[] W_ROOMS = {"DISPONIBLE", "AVAILABLE", "VACANCY", "HABITACION", "CUARTO", "ROOM", "ALQUILAR", "ALQUILO", "ALQUILER DE", "RENTAR",
            "BUSCO", "BUSCANDO", "LOOKING FOR", "INTERESAD", "INTERESTED", "PRECIO", "CUANTO CUESTA", "CUANTO ES", "CUANTO SALE", "HOW MUCH", "PRICE",
            "VER EL", "VERLO", "VERLA", "VISITA", "VISITAR", "VIEWING", "SHOWING", "MUDARME", "MUDARNOS", "MOVE IN", "MOVING", "APARTAMENTO", "APARTMENT", "APTO",
            "ESTUDIANTE", "STUDENT", "AMUEBLAD", "FURNISHED", "PARA EL MES", "DESDE EL", "ANUNCIO", "MARKETPLACE", "FACEBOOK", "LISTING", "REQUISITOS", "REQUIREMENTS"};
    static final String[] W_PAY = {"PAGO", "PAGUE", "PAGAR", "PAGA ", "PAGADO", "PAYMENT", "PAID", "PAY ", "E TRANSFER", "ETRANSFER", "TRANSFER", "INTERAC",
            "DEPOSITO", "DEPOSIT", "RECIBO", "RECEIPT", "FACTURA", "INVOICE", "COBRO", "COBRAR", "COBRARON", "DEBO", "DEUDA", "SALDO", "BALANCE",
            "EFECTIVO", "CASH", "COMPROBANTE", "ATRASAD", "LATE FEE", "RECARGO", "RENTA DE", "RENTA DEL", "LA RENTA", "MI RENTA", "RENT FOR", "MY RENT",
            "DEVOLUCION", "REEMBOLSO", "REFUND", "UTILIDADES", "UTILITIES"};

    static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return " " + n.toUpperCase(Locale.US).replaceAll("[^A-Z0-9 ]", " ").replaceAll("\\s+", " ").trim() + " ";
    }

    static int score(String t, String[] words) {
        int s = 0;
        for (String w : words) {
            int i = t.indexOf(" " + w); // si la palabra termina en espacio, tiene que ser la palabra completa
            if (i >= 0) s += w.trim().contains(" ") ? 2 : 1; // las frases cuentan más
        }
        return s;
    }

    /** Carpeta del texto, o "" si no hay pistas (por ejemplo «hola», «ok», «gracias»). */
    static String classify(String text) {
        String t = norm(text);
        int o = score(t, W_OPS), r = score(t, W_ROOMS), p = score(t, W_PAY);
        if (o == 0 && r == 0 && p == 0) return "";
        // empates: operaciones > pagos > habitaciones (un inquilino que dice «la ducha de mi cuarto» es operaciones)
        if (o >= p && o >= r) return OPS;
        if (p >= r) return PAY;
        return ROOMS;
    }

    /** La línea que dice de qué se trata (no el «hola»): la primera con pistas, o la más larga. */
    static String bestLine(String text) {
        String best = "";
        for (String l : text.split("\n")) { if (!classify(l).isEmpty()) return l; if (l.length() > best.length()) best = l; }
        return best.isEmpty() ? text : best;
    }

    static final Pattern MID = Pattern.compile("^(\\d+)\\|");

    /** Fecha (ms) que viene al inicio del id de un mensaje. */
    static long atOf(String mid) {
        Matcher m = MID.matcher(mid == null ? "" : mid);
        if (!m.find()) return 0;
        try { return Long.parseLong(m.group(1)); } catch (Exception e) { return 0; }
    }
}
